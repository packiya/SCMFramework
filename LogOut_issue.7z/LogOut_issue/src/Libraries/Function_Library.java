package Libraries;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.JavascriptExecutor;

import Utility.ReadExcel;
import Libraries.Driver_Script;

public class Function_Library extends Driver_Script {

	static int timeout_integer=0;
	public static Connection con = null;
	public static Statement stmt = null;
	public static ResultSet rs = null;
	static String XML_Request=null;
	static String Updated_XML_Request=null;
	static String gbstrXMLResponseData;

	//Static Variables to set the timeout for Webdriverwait methods. To getting the timeout values from Param.Property file
	static String getDisplayTimeout = null;
	static String getAlertTimeout = null;
	static int intElementDisplayTimeout = 0;
	static int intstaticAlertTimeout = 0;

	//XMLRequestResponse Declaration
	static DocumentBuilderFactory factory =null;
	static DocumentBuilder builder=null;
	static XPath xpath=null;
	static XPathFactory xpathfactory=null;
	static NodeList nodeList=null;
	static String strURL=null;	
	static String RequestXML=null;
	static Document document=null;
	static File file=null;
	static BufferedInputStream in=null;


	public static boolean Validate_AppComponent(String ComponentName,boolean testStepsStatus) throws Exception{
		boolean Validate_AppComponent= false;
		if(testStepsStatus){
			Report_Functions.ReportEventSuccess(doc, "1", "Validate_AppComponent", "Application Component '"+ComponentName+"' execution is  successful", 2);
			Validate_AppComponent = true;
		}else{
			Report_Functions.ReportEventFailure(doc, "Validate_AppComponent", "Application Component '"+ComponentName+"' execution is not successful", false);
			Validate_AppComponent = true;
		}
		return Validate_AppComponent;
	}

	public static String RetrieveTestDataValue(String strFunctionName,String strColumnName,int strExecEventFlag) throws Exception{
		String strData=null;
		//try{
		if(strExecEventFlag!=0){
			strData =ReadExcel.RetrieveTestDataFromSheet(Filepath, EnvironmentValue.getProperty("App_Component_Name"), strColumnName, gblrecordsCounter);
		}
		return strData;
	}

	public static int randomNumber()
	{
		int range = (9999 - 1000) + 1;     
		return (int)(Math.random() * range) + 1000;
	}

	/*----------------------------------------- FUNCTIONS BELOW-----------------------------------------*/

	/*----------------------------------------- DRIVER RELATED -----------------------------------------*/

	public static boolean launchApplication(String strAppName,int strExecEventFlag) throws Exception{
		boolean LaunchApplication= false;
		String strdata=null;
		String strURLdata=null;
		try{
			if(strExecEventFlag==1){
				strURLdata=RetrieveTestDataValue("LaunchApplication",strAppName,strExecEventFlag);
			}

			strdata=Param.getProperty(strURLdata);

			log.info("strdata is "+strdata);

			if(strdata==null){
				Report_Functions.ReportEventFailure(doc,  "LaunchApplication",  "Required details are not provided.", false);
				return false;
			}

			//Kill all the existing browsers at the start of Launch Application
			try{
				if(Param.getProperty("To_Kill_All_Running_Browsers").equalsIgnoreCase("True")){
					Runtime.getRuntime().exec("taskkill /F /IM " + Param.getProperty("Chrome_ImageName"));
					Thread.sleep(1000);
				}
			}catch(Exception e){
				log.info("Exception occured while killing the Existing running browsers. Exception occured is : "+ e);
				throw e;
			}

			//Kill all the existing browsers at the start of Launch Application
			try{
				if(Param.getProperty("To_Kill_Browser_Driver").equalsIgnoreCase("True")){
					log.info("Chrome browser driver running. Killing the Process before start of TestCase.");
					Runtime.getRuntime().exec("taskkill /F /IM " + Param.getProperty("ChromeDriver_ImageName"));
					Thread.sleep(3000);
				}
			}catch(Exception e){
				log.info("Exception occured while killing the browser drivers. Exception occured is : "+ e);
				throw e;
			}

			if(Param.getProperty("testBrowser").equalsIgnoreCase("Mozilla")){
				driver = new FirefoxDriver();
				log.info("Firefox Driver Instance loaded successfully.");
			}else if(Param.getProperty("testBrowser").equalsIgnoreCase("Chrome")){
				System.setProperty("webdriver.chrome.driver","./BrowserDrivers/chromedriver.exe");
				driver = new ChromeDriver();
			}else if(Param.getProperty("testBrowser").equalsIgnoreCase("IE")){
				System.setProperty("webdriver.ie.driver", "./BrowserDrivers/IEDriverServer.exe");
			}

			driver.manage().window().maximize();
			driver.get(strdata);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			Report_Functions.ReportEventSuccess(doc, "1", "LaunchApplication", "URL '"+strdata+"' launched successfully", 2);
			LaunchApplication = true;
			
		} catch(WebDriverException e){

			driver.get(strdata);
			log.info("Error occurred in launch application :" +e.getMessage());
			launchApplication(strAppName, strExecEventFlag);
			LaunchApplication = false;

		} catch(Exception e){
			Report_Functions.ReportEventFailure(doc, "LaunchApplication", "Error in opening the application '"+strdata+"'", false);		
			log.info("Exception in LaunchApplication is : "+ e);
			LaunchApplication=false;
		}
		return LaunchApplication;
	}

	public static boolean closeWebBrowser() throws Exception{

		boolean CloseWebBrowser=false;
		String strBrowserName=null;
		try{
			if(Param.getProperty("testBrowser").equalsIgnoreCase("Mozilla")){
				strBrowserName = "Mozilla";
			}else if(Param.getProperty("testBrowser").equalsIgnoreCase("chrome")){
				strBrowserName = "chrome";
			}else if(Param.getProperty("testBrowser").equalsIgnoreCase("IE")){
				strBrowserName = "IE";
			}		

			try{
				driver.close();
				log.info("Closing the Focused Browser.");
			}catch(Exception e){
				log.info("close : "+e);
			}
			try{
				if(driver!=null){
					log.info("Quiting the Driver Session!");	
					driver.quit();
				}
			}catch(Exception e){
				log.info("quit : "+e);
			}

			Report_Functions.ReportEventSuccess(doc,"1", "CloseBrowser", "Successfully Closed the browser "+ strBrowserName, 2);
			CloseWebBrowser=true;
		}catch(Exception e){
			log.info("In Exception of close browser. Exception is : " + e);
			Report_Functions.ReportEventFailure(doc, "CloseBrowser", "Unable to close the browser "+strBrowserName, false);
			CloseWebBrowser=false;
		}finally{
			driver=null;
		}
		return CloseWebBrowser;
	}

	/*--------------------------------- WEBELEMENT FUNCTIONS-----------------------------------------*/

	public static boolean webelementEnterText(String getValueFromPOM, String strTestObject,String strColumnName,int strExecEventFlag )throws Exception  {

		boolean WebEditEnterText= false;
		String strData=null;
		try {
			if(strExecEventFlag==1){
				strData=RetrieveTestDataValue("",strColumnName,strExecEventFlag);
			}

			if(strData==null){
				Report_Functions.ReportEventFailure(doc,  "WebEditEnterUsername",  "Required details are not provided in the data sheet.", false);
				return false;
			}

			selectByLocatorType(getValueFromPOM).clear();
			selectByLocatorType(getValueFromPOM).sendKeys(strData);
			Report_Functions.ReportEventSuccess(doc, "1", "WebEditEnterText", "The Text '" +  strData + "' is entered in the Textbox -  '"+strTestObject+"'  successfully", 3);
			WebEditEnterText=true;	
		} catch (Exception e) { 	
			Report_Functions.ReportEventFailure(doc, "WebEditEnterText", "The Text '" + strData + "' was not entered in the Textbox - '"+strTestObject+"'", true);
			WebEditEnterText=false;
			log.info("No Element Found to enter text : " + e);
		}
		return WebEditEnterText;
	}

	public static boolean webelementEnterUsername(String getValueFromPOM, String strTestObject,String strColumnName,int strExecEventFlag ) throws Exception {

		boolean WebEditEnterUsername= false;
		String strData=null;
		String strUserID=null;
		try {

			if(strExecEventFlag==1){
				strData=RetrieveTestDataValue("WebEditEnterUsername",strColumnName,strExecEventFlag);
			}

			if(strData==null){
				Report_Functions.ReportEventFailure(doc,  "WebEditEnterUsername",  "Required details are not provided in the data sheet.", false);
				return false;
			}

			if(Param.getProperty("Use_ENV_UserID_Password").equalsIgnoreCase("Yes")){
				strUserID=Param.getProperty(strData);
			}else{
				strUserID=strData;
			}

			if(strUserID==null){
				Report_Functions.ReportEventFailure(doc,  "WebEditEnterUsername",  "No value to enter in the field : '"+ strTestObject +"'.", false);
				return false;
			}
			selectByLocatorType(getValueFromPOM).sendKeys(strUserID);
			Report_Functions.ReportEventSuccess(doc,"1","WebEditEnterUsername ","The Value '" +  strUserID + "' is entered in the '"+strTestObject+"' TextBox successfully",3);		
			WebEditEnterUsername = true;
		}catch (Exception e) {
			Report_Functions.ReportEventFailure(doc,"WebEditEnterUsername","The Value '" + strUserID + "' was not entered in the '"+strTestObject+"' textbox'", true);
			WebEditEnterUsername = false;
			log.info("No Element Found to enter UserID : " + e);
		}
		return WebEditEnterUsername;
	}

	public static boolean webelementEnterPassword(String getValueFromPOM, String strTestObject,String strColumnName,int strExecEventFlag ) throws Exception {

		boolean WebEditEnterPassword= false;
		String strData=null;
		String strUserID=null;
		try {

			if(strExecEventFlag==1){
				strData=RetrieveTestDataValue("WebEditEnterPassword",strColumnName,strExecEventFlag);
			}

			if(strData==null){
				Report_Functions.ReportEventFailure(doc,  "WebEditEnterUsername",  "Required details are not provided in the data sheet.", false);
				return false;
			}


			if(Param.getProperty("Use_ENV_UserID_Password").equalsIgnoreCase("Yes")){
				strUserID=Param.getProperty(strData);
			}else{
				strUserID=strData;
			}

			if(strUserID==null){
				strUserID = "";
			}

			selectByLocatorType(getValueFromPOM).sendKeys(strUserID);
			Report_Functions.ReportEventSuccess(doc,"1","WebEditEnterPassword ","The Value is entered in the '"+strTestObject+"' TextBox successfully",3);		
			WebEditEnterPassword = true;
		}catch (Exception e) {
			Report_Functions.ReportEventFailure(doc,"WebEditEnterPassword","The Value was not entered in the '"+strTestObject+"' textbox'", true);
			WebEditEnterPassword = false;
			log.info("No Element Found to enter UserID : " + e);
		}
		return WebEditEnterPassword;
	}

	public static boolean webelementEnterTextWithRandomNumber(String getValueFromPOM, String strTestObject,String strColumnName,int strExecEventFlag )throws Exception  {

		boolean WebEditEnterText= false;
		String strData=null;
		try {
			if(strExecEventFlag==1){
				strData=RetrieveTestDataValue("WebEditEnterText",strColumnName,strExecEventFlag);
			}

			if(strData==null){
				Report_Functions.ReportEventFailure(doc,  "WebEditEnterUsername",  "Required details are not provided in the data sheet.", false);
				return false;
			}

			int randomNo = randomNumber();
			strData=strData+randomNo;

			selectByLocatorType(getValueFromPOM).clear();
			selectByLocatorType(getValueFromPOM).sendKeys(strData);
			Report_Functions.ReportEventSuccess(doc, "1", "WebEditEnterText", "The Text with Random Number '" +  strData + "' is entered in the Textbox -  '"+strTestObject+"'  successfully", 3);
			WebEditEnterText=true;	
		} catch (Exception e) { 	
			Report_Functions.ReportEventFailure(doc, "WebEditEnterText", "The Text with Random Number '" + strData + "' was not entered in the Textbox - '"+strTestObject+"'", true);
			WebEditEnterText=false;
			log.info("No Element Found to enter text : " + e);
		}
		return WebEditEnterText;
	}

	public static boolean webelementEnterTextWithRandomNumberAtFront(String getValueFromPOM, String strTestObject,String strColumnName,int strExecEventFlag )throws Exception  {

		boolean WebEditEnterText= false;
		String strData=null;
		try {
			if(strExecEventFlag==1){
				strData=RetrieveTestDataValue("WebEditEnterText",strColumnName,strExecEventFlag);
			}

			if(strData==null){
				Report_Functions.ReportEventFailure(doc,  "WebEditEnterUsername",  "Required details are not provided in the data sheet.", false);
				return false;
			}

			int randomNo = randomNumber();
			strData="_"+randomNo+strData;

			selectByLocatorType(getValueFromPOM).clear();
			selectByLocatorType(getValueFromPOM).sendKeys(strData);
			Report_Functions.ReportEventSuccess(doc, "1", "WebEditEnterText", "The Text with Random Number '" +  strData + "' is entered in the Textbox -  '"+strTestObject+"'  successfully", 3);
			WebEditEnterText=true;	
		} catch (Exception e) { 	
			Report_Functions.ReportEventFailure(doc, "WebEditEnterText", "The Text with Random Number '" + strData + "' was not entered in the Textbox - '"+strTestObject+"'", true);
			WebEditEnterText=false;
			log.info("No Element Found to enter text : " + e);
		}
		return WebEditEnterText;
	}

	public static boolean webelementClick(String getValueFromPOM, String strTestObject)throws Exception  {

		boolean WebElementClick= false;
		try {
			selectByLocatorType(getValueFromPOM).click();
			Report_Functions.ReportEventSuccess (doc,"1","","'"+strTestObject+"' is clicked successfully ",2);	
			WebElementClick=true;
		}catch(StaleElementReferenceException e){
			return webelementClick(getValueFromPOM, strTestObject);
		}
		catch (Exception e) {
			Report_Functions.ReportEventFailure(doc,"","'"+strTestObject+"' was not clicked" , true); 
			WebElementClick=false;
			log.info("No Element Found to click :" + e);
		}
		return WebElementClick;
	}

	public static boolean weblinkClick(String getValueFromPOM, String strTestObject) throws Exception {

		boolean WebLinkClick= false;
		try {
			selectByLocatorType(getValueFromPOM).click();
			Report_Functions.ReportEventSuccess(doc,"1","","The Link: '"+strTestObject+"' clicked successfully",3);
			WebLinkClick=true;
		} catch (Exception e) {
			Report_Functions.ReportEventFailure(doc,"","'The Link: "+strTestObject+"' was not clicked" , true); 
			WebLinkClick=false;
			log.info("No Element Found to click : " + e);
		}
		return WebLinkClick;
	}

	public static boolean webradioSelect(String getValueFromPOM, String strTestObject, String rdbOptions)throws Exception  {

		boolean WebRadioSelect= false;
		try {
			selectByLocatorType(getValueFromPOM).click();
			Report_Functions.ReportEventSuccess(doc,"4","","Selected the Option '"+rdbOptions+"' from the Radio button '" + strTestObject + "'",3);		
			WebRadioSelect=true;
		} catch (Exception e) {
			Report_Functions.ReportEventFailure(doc,"","The Option '"+rdbOptions+"' is not Selected from the Radio button '" + strTestObject + "'", true); 	
			WebRadioSelect=false;
			log.info("No Element Found to Select : " + e);
		}
		return WebRadioSelect;
	}

	public static boolean webelementTabClick(String getValueFromPOM, String strTestObject)throws Exception  {

		boolean elementStatus = false;
		try {
			if(selectByLocatorType(getValueFromPOM).isDisplayed()){
				selectByLocatorType(getValueFromPOM).sendKeys(Keys.TAB);			
				Report_Functions.ReportEventSuccess(doc,"1","webElementTabClick","Tab button is clicked successfully on '"+strTestObject+"' field",3);		
				elementStatus = true;
			}else{

				Report_Functions.ReportEventFailure(doc,"webElementTabClick","Element is not found and Tab button is not clicked on '"+strTestObject+"' field", true); 	
				elementStatus = false;

			}
		} catch (Exception e) {
			Report_Functions.ReportEventFailure(doc,"webElementTabClick","Exception occurred in 'webElementTabClick' function", true); 	
			elementStatus = false;
			log.info("No Element Found to click : " + e);
		}
		return elementStatus;
	}

	public static boolean webelementEnterValuesAndClickEnterBtn(String getValueFromPOM, String strTestObject, String strColumnName, int strExecEventFlag)throws Exception  {

		boolean enterValuesAndClickEnter = false;

		String strData = null;
		try {
			if(strExecEventFlag == 1){
				strData = RetrieveTestDataValue("EnterValuesAndClickEnter", strColumnName, strExecEventFlag);
			}

			if(strData==null){
				Report_Functions.ReportEventFailure(doc,  "WebEditEnterUsername",  "Required details are not provided in the data sheet.", false);
				return false;
			}

			WebElement element = selectByLocatorType(getValueFromPOM);

			if(element.isDisplayed()){

				selectByLocatorType(getValueFromPOM).clear();
				selectByLocatorType(getValueFromPOM).sendKeys(strData);
				selectByLocatorType(getValueFromPOM).sendKeys(Keys.ENTER);

				Report_Functions.ReportEventSuccess(doc, "1", "EnterValuesAndClickEnter", "Text '" +  strData + "' is entered in the Textbox -  '"+strTestObject+"' and clicked on 'ENTER' button successfully", 3);
				enterValuesAndClickEnter = true;

			}else{

				Report_Functions.ReportEventFailure(doc, "EnterValuesAndClickEnter", "Text '" + strData + "' was not entered in the Textbox - '"+strTestObject+"' and not clicked on 'ENTER' button", true);
				enterValuesAndClickEnter = false;

			}
		} catch (Exception e) { 	
			Report_Functions.ReportEventFailure(doc, "EnterValuesAndClickEnter", "Text '" + strData + "' was not entered in the Textbox - '"+strTestObject+"' and not clicked on 'ENTER' button", true);
			enterValuesAndClickEnter = false;
			log.info("No Element Found to enter text : " + e);
		}
		return enterValuesAndClickEnter;
	}

	public static boolean webelementTextCompare(String getValueFromPOM,String strTestObject,String strexpectedValue,int strExecEventFlag) throws Exception  {
		boolean WebEditTextCompare=false;
		String ActualValue=null;
		String ExpectedValue=null;
		try {
			if(strExecEventFlag==1){
				ExpectedValue = RetrieveTestDataValue("",strexpectedValue,strExecEventFlag);
			}
			if(ExpectedValue==null){
				Report_Functions.ReportEventFailure(doc,  "",  "Required details are not provided in test data sheet.", false);
				return false;
			}

			ActualValue = selectByLocatorType(getValueFromPOM).getText();
		}catch (Exception e) {
			Report_Functions.ReportEventFailure(doc,"WebEditTextCompare",  "Error occured while getting the text from the input field :'"+strTestObject+"'and the error description is :"+e.getMessage(), true);
			WebEditTextCompare=false;
		}

		try{
			if((ActualValue.trim()).equals(ExpectedValue.trim())){
				Report_Functions.ReportEventSuccess(doc,"1", "", "The  Actual Value '" +ActualValue+ "' matches with the Expected value '"+ExpectedValue+ "' in the input field '"+strTestObject+"", 2);
				WebEditTextCompare=true;
			}else{
				Report_Functions.ReportEventFailure(doc,"", "The  Actual Value '" +ActualValue+ "' does not match with the Expected value '"+ExpectedValue+ "' in the input field '"+strTestObject+"", true);
				WebEditTextCompare=false;
			}
		}catch (Exception e) {
			Report_Functions.ReportEventFailure(doc,"",  "Error occured while comparing actual and expected values. Error description is :"+e.getMessage(), true);
			WebEditTextCompare=false;
		}
		return WebEditTextCompare;
	}

	public static boolean webelementTextCompareFromEnv(String getValueFromPOM, String strTestObject,String strColumnName,int strExecEventFlag )throws Exception  {
		String actualResult=null;
		String strData=null;
		boolean WebElementValueCompareFromEnv=false;
		try{
			if (strExecEventFlag==1){
				strData=RetrieveTestDataValue("WebElementValueCompareFromEnv",strColumnName,strExecEventFlag);
				strData=Runtimevalue.getProperty(strData);
			}
			if(strData==null){
				Report_Functions.ReportEventFailure(doc,  "RetrieveRRBSValueStoresInEnvVar",  "Required details are not provided in the data sheet.", false);
				return false;
			}
			actualResult = selectByLocatorType(getValueFromPOM).getText();

		} catch (Exception e){
			Report_Functions.ReportEventFailure(doc,"WebElementValueCompareFromEnv", "Error occured while getting the text from the WebElement :'"+strTestObject+"'and the error description is :"+e.getMessage(), true);
			WebElementValueCompareFromEnv=false;
		}

		try{
			if((actualResult.trim()).equalsIgnoreCase(strData.trim())){
				Report_Functions.ReportEventSuccess(doc,"1", "WebElementValueCompareFromEnv", "The  Actual Value '" +actualResult+ "' matches with the Expected value '"+strData+ "' in the input field '"+strTestObject+"'", 2);
				WebElementValueCompareFromEnv=true;
			}else{
				Report_Functions.ReportEventFailure(doc,"WebElementValueCompareFromEnv", "The  Actual Value '" +actualResult+ "' does not match with the Expected value '"+strData+ "' in the input field '"+strTestObject+"'", true);
				WebElementValueCompareFromEnv=false;
			}
		} catch (Exception e){
			Report_Functions.ReportEventFailure(doc,"WebElementValueCompareFromEnv", "Error occured while comparing actual and expected values. Error description is :"+e.getMessage(), true);
			WebElementValueCompareFromEnv=false;
		}
		return WebElementValueCompareFromEnv;
	}

	public static boolean webelementDynamicStringVerify(String getValueFromPOM, String strTestObject, String strPattern,int strExecEventFlag) throws Exception{
		boolean WebElementDynamicStringVerify=false;
		boolean matchedStatus=false;
		Matcher matchedPattern = null;
		String Pattern_String = null;
		String RetrievedMessage=null;
		try{
			if(strExecEventFlag==1){
				Pattern_String=RetrieveTestDataValue("WebElementDynamicStringVerify",strPattern,strExecEventFlag);
			}

			if(Pattern_String==null){
				Report_Functions.ReportEventFailure(doc,  "WebElementDynamicStringVerify",  "Required details are not provided in test data sheet.", false);
				return false;
			}
			Pattern_String = Pattern_String.trim();
			RetrievedMessage=selectByLocatorType(getValueFromPOM).getText().trim();
			Pattern expPattern=Pattern.compile(Pattern_String);
			matchedPattern = expPattern.matcher(RetrievedMessage);
			matchedStatus=matchedPattern.find();
		}catch(Exception e){
			Report_Functions.ReportEventFailure(doc,  "WebElementDynamicStringVerify",  "Error occured while matching the Expected pattern-matchedPattern.find():"+e.getMessage(), true);
			WebElementDynamicStringVerify=false;
		}

		try{
			if(matchedStatus==true){
				log.info("Matched status pass:"+matchedStatus);
				Report_Functions.ReportEventSuccess(doc, "1", "WebElementDynamicStringVerify", "The Expected pattern '"+Pattern_String+"' in the webElement '"+strTestObject+"' matches with the actual pattern: '"+RetrievedMessage+"' successfully", 2);
				//Report_Functions.ReportEventSuccess(doc, "1", "WebElementDynamicStringVerify", "Retrieved pattern from the webElement '"+strTestObject+"'. Matched Successfully'"+matchedPattern.group()+"'", 2);
				WebElementDynamicStringVerify=true;
			}else if(matchedStatus==false){
				log.info("Matched status fail:"+matchedStatus);
				Report_Functions.ReportEventFailure(doc,  "WebElementDynamicStringVerify",  "The Expected pattern '"+Pattern_String+"' in the webElement '"+strTestObject+"' does not match with the actual pattern: '"+RetrievedMessage+"'", true);
				WebElementDynamicStringVerify=false;
			}
		} catch (Exception e){
			Report_Functions.ReportEventFailure(doc,  "WebElementDynamicStringVerify",  "Error occured while finding the Pattern in the function 'WebElementDynamicStringVerify'.Error description is : "+ e.getMessage() +".", true);
			log.info("WebElementDynamicStringVerify Error : " + e);
			WebElementDynamicStringVerify=false;
		}
		return WebElementDynamicStringVerify;
	}

	public static boolean webelementEnabled(String getValueFromPOM, String strTestObject) throws Exception {

		boolean elementenable;
		boolean WebElementEnabled = false;
		try {
			elementenable=selectByLocatorType(getValueFromPOM).isEnabled();

			if(elementenable){
				WebElementEnabled = true;
				Report_Functions.ReportEventSuccess(doc, "1", "", "The object '"+strTestObject+"' is enabled as expected.", 3);
			}else{
				WebElementEnabled=false;
				Report_Functions.ReportEventFailure(doc, "", "The object '"+strTestObject+"' is not enabled.", true);
			}

		} catch (Exception e) { 	
			log.info("Exception while finding enabled or disabled" + e);
			WebElementEnabled=false;
		}
		return WebElementEnabled;
	}

	public static boolean webelementDisabled(String getValueFromPOM, String strTestObject) throws Exception {

		boolean elementenable;
		boolean WebElementDisabled = false;
		try {
			elementenable=selectByLocatorType(getValueFromPOM).isEnabled();

			if(elementenable){
				WebElementDisabled=false;
				Report_Functions.ReportEventFailure(doc, "", "The object '"+strTestObject+"' is not disabled.", true);
			}else{
				WebElementDisabled = true;
				Report_Functions.ReportEventSuccess(doc, "1", "", "The object '"+strTestObject+"' is disabled as expected.", 3);
			}

		} catch (Exception e) { 	
			log.info("Exception while finding enabled or disabled" + e);
			WebElementDisabled=false;
		}
		return WebElementDisabled;
	}

	/*--------------------------------- WAIT FUNCTIONS-----------------------------------------*/

	public static boolean waitUntilElementExist(String getValueFromPOM,  String strTestObject) throws Exception {

		boolean elementStatus= false;
		getDisplayTimeout = Param.getProperty("elementDisplayTimeout");
		intElementDisplayTimeout = Integer.parseInt(getDisplayTimeout);

		WebElement element = null;
		WebDriverWait wait = new WebDriverWait(driver,intElementDisplayTimeout);

		try{

			String loc = Runtimevalue.getProperty("locatorType");

			switch(loc.toLowerCase()){

			case "id":
				element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(getValueFromPOM)));
				if(element.isDisplayed()){
					elementStatus = true;
				}else{
					elementStatus = false;
				}
				break;


			case "xpath":
				element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(getValueFromPOM)));
				if(element.isDisplayed()){
					elementStatus = true;
				}else{
					elementStatus = false;
				}
				break;

			case "css":
				element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(getValueFromPOM)));
				if(element.isDisplayed()){
					elementStatus = true;
				}else{
					elementStatus = false;
				}
				break;

			case "classname":	
				element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className(getValueFromPOM)));
				if(element.isDisplayed()){
					elementStatus = true;
				}else{
					elementStatus = false;
				}
				break;

			case "name":
				element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name(getValueFromPOM)));
				if(element.isDisplayed()){
					elementStatus = true;
				}else{
					elementStatus = false;
				}
				break;

			case "linktext":
				element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText(getValueFromPOM)));
				if(element.isDisplayed()){
					elementStatus = true;
				}else{
					elementStatus = false;
				}
				break;

			case "tagname":
				element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName(getValueFromPOM)));
				if(element.isDisplayed()){
					elementStatus = true;
				}else{
					elementStatus = false;
				}
				break;

			case "partiallinktext":
				element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.partialLinkText(getValueFromPOM)));
				if(element.isDisplayed()){
					elementStatus = true;
				}else{
					elementStatus = false;
				}
				break;

			default:

				elementStatus = false;
				throw new IllegalArgumentException("Unable to found");
			}	

		}catch(StaleElementReferenceException e1){
			return waitUntilElementExist(getValueFromPOM, strTestObject);
		}catch(Exception e){
			log.info("Exception Occured in 'waitUntilExist':"+ e);
			elementStatus = false;
		}

		if(elementStatus){
			Report_Functions.ReportEventSuccess(doc,"1","","The element '"+ strTestObject +"' is displayed successfully",3);
		}else{
			Report_Functions.ReportEventFailure(doc,"","The element '"+ strTestObject +"' is not displayed within time of "+intElementDisplayTimeout+" seconds" , true);
		}
		return elementStatus;
	}	

	public static boolean waitUntilDisappear(String getValueFromPOM, String strTestObject) throws Exception{

		boolean disappear =false;

		try{
			log.info("Check element is appear");
			Thread.sleep(500);
			if(selectByLocatorType(getValueFromPOM).isDisplayed()){

				for(int i=0; i<90; i++){
					Thread.sleep(1000);
					log.info("Element is appearing");

					if(!selectByLocatorType(getValueFromPOM).isDisplayed()){

						disappear = true;
						log.info("Element is disappeared");
						Thread.sleep(1000);
						Report_Functions.ReportEventSuccess(doc,"1","","'The element '"+ strTestObject +"' is disappeared.",3);
						break;
					}
				}

			}else{

				Thread.sleep(500);
				log.info("Element doesn't exist");
				disappear = true;
				Thread.sleep(1000);
				Report_Functions.ReportEventSuccess(doc,"1","","'The element '"+ strTestObject +"' is not displayed",3);

			}

		}catch(StaleElementReferenceException e){

			Report_Functions.ReportEventSuccess(doc,"1","","'The element '"+ strTestObject +"' is not displayed",3);
			return true;


		}
		catch(NullPointerException e){

			log.info("Null pointer exception occurred :"+e);
			Report_Functions.ReportEventSuccess(doc,"1","","'The element '"+ strTestObject +"' is not displayed",3);
			return true;

		}catch(Exception e){

			log.info("Element is not found :"+e);
			disappear = false;
			Report_Functions.ReportEventFailure(doc,"","Exception occured. Error message is : "+ e +"." , true);
		}

		return disappear;

	}

	public static boolean waitUntilTextPresent(String getValueFromPOM, String strTestObject) throws Exception {
		boolean elementStatus= false;
		getDisplayTimeout = Param.getProperty("elementDisplayTimeout");
		intElementDisplayTimeout = Integer.parseInt(getDisplayTimeout);

		try{
			elementStatus = new WebDriverWait(driver,intElementDisplayTimeout).until(new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver driver) {
					return selectByLocatorType(getValueFromPOM).getText().length() != 0;
				}
			});
		} catch(StaleElementReferenceException e1){
			return waitUntilTextPresent(getValueFromPOM, strTestObject);
		} catch(Exception e){
			Report_Functions.ReportEventFailure(doc,"","Error occured while waiting for the element : '"+ strTestObject +"'.Error description is : "+ e +"." , true);
			elementStatus = false;
		}

		if(elementStatus){
			Report_Functions.ReportEventSuccess(doc,"1","","'The text is present in '"+ strTestObject +"' successfully",3);
			return elementStatus;
		}else{
			Report_Functions.ReportEventFailure(doc,"","'The text is not present in '"+ strTestObject +"'." , true);
			return elementStatus;
		}
	}

	public static boolean waitUntilValuePresent(String getValueFromPOM, String strTestObject) throws Exception {
		boolean elementStatus= false;
		int icount = 0;

		try{

			if((selectByLocatorType(getValueFromPOM)).getAttribute("value").length() != 0){
				elementStatus = true;
			}

			while((selectByLocatorType(getValueFromPOM)).getAttribute("value").length() == 0){

				if((selectByLocatorType(getValueFromPOM)).getAttribute("value").length() != 0){
					elementStatus = true;
					break;
				}
				if(icount == 10  && (selectByLocatorType(getValueFromPOM)).getAttribute("value").length() == 0){
					break;
				}
				icount = icount + 1;
			}
		} catch(StaleElementReferenceException e1){
			return waitUntilValuePresent(getValueFromPOM, strTestObject);
		} catch(Exception e){
			Report_Functions.ReportEventFailure(doc,"","Error occured while waiting for the element : '"+ strTestObject +"'.Error description is : "+ e +"." , true);
			elementStatus = false;
		}

		if(elementStatus){
			Report_Functions.ReportEventSuccess(doc,"1","","'The text is present in "+ strTestObject +"' successfully",3);
			return elementStatus;
		}else{
			Report_Functions.ReportEventFailure(doc,"","'The text is not present in "+ strTestObject +"'." , true);
			return elementStatus;
		}
	}

	public static boolean waitUntilListLoads(String getValueFromPOM, String strTestObject)throws Exception  {

		String strData=null;
		boolean WebListSelect=false;
		Select se=null;
		List<WebElement> options=null;

		try{

			int i=0;
			int listSize=0;
			boolean displayed=false;
			while(i<10){
				Thread.sleep(1000);

				se=new Select(selectByLocatorType(getValueFromPOM));
				options = se.getOptions();

				log.info("Size of Wiblist is : "+options.size());
				listSize=options.size();
				if(options.size()>1){
					log.info("List is populated");
					displayed=true;
					break;
				}else{
					log.info("List yet not populated");
				}

				i++;
			}

			if(displayed){
				Report_Functions.ReportEventSuccess(doc,"1","","The List is Loaded for the dropdown '"+strTestObject+"' successfully" ,3);
				WebListSelect=true;
			}else{
				if(listSize==1){
					Report_Functions.ReportEventSuccess(doc,"1","","The List has only one value Loaded for the dropdown '"+strTestObject+"'" ,3);
				}
				WebListSelect=true;
			}

		} catch (StaleElementReferenceException e) {
			return waitUntilListLoads(getValueFromPOM, strTestObject);
		} catch (Exception e) {
			Report_Functions.ReportEventFailure(doc,"","The Item '" +  strData + " was not selected from the  '"+strTestObject+"' List box " , true); 
			WebListSelect=false;
			log.info("No Element Found to select text" + e);
		}
		return WebListSelect;
	}

	/*--------------------------------- ACTIONS FUNCTIONS-----------------------------------------*/

	public static boolean actionMoveToElementAndClick(String getValueFromPOM, String strOject) throws Exception {

		boolean elementStatus= false;

		try{
			//Thread.sleep(2000);
			WebElement element=selectByLocatorType(getValueFromPOM);
			Actions action = new Actions(driver);
			action.moveToElement(element).click(element).build().perform();
			elementStatus=true;
		}catch(Exception e){
			log.info("Exception Occured in PerformActionMoveToElementAndClick. Exception is : "+ e);
			elementStatus = false;
		}

		if(elementStatus){
			Report_Functions.ReportEventSuccess(doc,"1","","Mouse moved to the element '"+strOject+"' and click is done",3);
		}else{
			Report_Functions.ReportEventFailure(doc,"","Mouse not  moved to the element '"+strOject+"' and click action is not performed" , true);
		}

		return elementStatus;
	}

	public static boolean webelementDoubleClickOnElement(String getValueFromPOM, String strTestObject) throws Exception{

		boolean doubleClickOnElement = false;

		try {
			WebElement element = selectByLocatorType(getValueFromPOM);

			if(element.isDisplayed()){

				Actions action = new Actions(driver).doubleClick(element);
				action.build().perform();
				Report_Functions.ReportEventSuccess (doc,"1","DoubleClickOnElement","'"+strTestObject+"' is double clicked successfully ",2);	
				doubleClickOnElement = true;

			}else{

				Report_Functions.ReportEventFailure(doc,"DoubleClickOnElement","'"+strTestObject+"' was not double clicked" , true); 
				doubleClickOnElement = false;


			}

		} catch (Exception e) {
			Report_Functions.ReportEventFailure(doc,"DoubleClickOnElement","'"+strTestObject+"' was not double clicked" , true); 
			doubleClickOnElement = false;
			log.info("No Element Found to double click :" + e);
		}
		return doubleClickOnElement;
	}

	public static boolean weblistSelect(String getValueFromPOM, String strTestObject,String strColumnName,int strExecEventFlag)throws Exception  {

		String strData=null;
		boolean WebListSelect=false;
		try {
			if(strExecEventFlag==1){
				strData=RetrieveTestDataValue("WebListSelect",strColumnName,strExecEventFlag);
			}
			if(strData==null){
				Report_Functions.ReportEventFailure(doc,  "WebListSelect",  "Required details are not provided in the data sheet.", false);
				return false;
			}

			new Select(selectByLocatorType(getValueFromPOM)).selectByVisibleText(strData);
			Report_Functions.ReportEventSuccess(doc,"1","","The Item '" +  strData + "' is selected from the  '"+strTestObject+"' List box successfully" ,3);
			WebListSelect=true;

		} catch (StaleElementReferenceException e) {
			return weblistSelect(getValueFromPOM, strTestObject, strColumnName, strExecEventFlag);

		} catch (Exception e) {
			Report_Functions.ReportEventFailure(doc,"","The Item '" +  strData + " was not selected from the  '"+strTestObject+"' List box " , true); 
			WebListSelect=false;
			log.info("No Element Found to select text" + e);
		}
		return WebListSelect;
	}

	public static WebElement selectByLocatorType(String getValueFromPOM){
		WebElement element = null;

		try{
			String loc = Runtimevalue.getProperty("locatorType");
			switch(loc.toLowerCase()){
			case "id":element = driver.findElement(By.id(getValueFromPOM));
				break;
			case "xpath": 	element = driver.findElement(By.xpath(getValueFromPOM));
				break;
			case "css":	element = driver.findElement(By.cssSelector(getValueFromPOM));
				break;
			case "classname":	element = driver.findElement(By.className(getValueFromPOM));
				break;
			case "name":	element = driver.findElement(By.name(getValueFromPOM));
				break;
			case "linktext":	element = driver.findElement(By.linkText(getValueFromPOM));
				break;
			case "tagname": element = driver.findElement(By.tagName(getValueFromPOM));
				break;
			case "partiallinktext": element = driver.findElement(By.partialLinkText(getValueFromPOM));
				break;
			default:
				throw new IllegalArgumentException("Unable to found");
			}	

		}catch(StaleElementReferenceException e1){
			return selectByLocatorType(getValueFromPOM);
		}catch (Exception e) {
			log.info("Exception: Element is not found ;"+ e);
		}	
		return element;
	}

	public static List<WebElement> weblistSelectByLocatorType(String getValueFromPOM){

		List<WebElement> element = null;

		try{

			String loc = Runtimevalue.getProperty("locatorType");

			switch(loc.toLowerCase()){

			case "id":
				element = driver.findElements(By.id(getValueFromPOM));
				break;

			case "xpath":
				element = driver.findElements(By.xpath(getValueFromPOM));
				break;

			case "css":
				element = driver.findElements(By.cssSelector(getValueFromPOM));
				break;

			case "classname":	
				element = driver.findElements(By.className(getValueFromPOM));
				break;

			case "name":
				element = driver.findElements(By.name(getValueFromPOM));
				break;

			case "linktext":
				element = driver.findElements(By.linkText(getValueFromPOM));
				break;

			case "tagname":
				element = driver.findElements(By.tagName(getValueFromPOM));
				break;

			case "partiallinktext":
				element = driver.findElements(By.partialLinkText(getValueFromPOM));
				break;

			default:

				throw new IllegalArgumentException("Unable to found");

			}	

		}catch(StaleElementReferenceException e1){
			return weblistSelectByLocatorType(getValueFromPOM);
		}catch (Exception e) {
			log.info("Exception: Element is not found ;"+ e);
			throw e;
		}

		return element;
	}


	/*--------------------------------- JAVA SCRIPT-----------------------------------------*/

	public static boolean javaScriptDatePicker(String getValueFromPOM, String strTestObject, String strColumnName, int strExecEventFlag) throws Exception{

		boolean elementStatus = false;
		String elementValue = null;

		try{

			if(strExecEventFlag==1){

				elementValue = RetrieveTestDataValue("javaScriptDatePicker", strColumnName, strExecEventFlag);

			}

			if(elementValue == null){

				Report_Functions.ReportEventFailure(doc,  "javaScriptDatePicker",  "Required details are not provided in the data sheet.", false);
				return false;

			}

			//Get the locatorType from POM during runtime
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("document.getElementById('"+getValueFromPOM+"').value = '"+elementValue+"'");
			Report_Functions.ReportEventSuccess (doc,"1","","Date picker value '"+elementValue+"' is entered for "+strTestObject+" ",2);	
			elementStatus = true;

		}catch(Exception e){

			log.info("Exception occurred in web table radio button :"+e.getMessage());
			e.printStackTrace();
			Report_Functions.ReportEventFailure(doc,"","Date picker value '"+elementValue+"' is not entered for "+strTestObject+" " , true);  
			elementStatus = false;

		}

		return elementStatus;

	}

	public static boolean javaScriptWebElementClick(String getValueFromPOM, String strTestObject)throws Exception  {

		boolean WebElementClick= false;
		try {

			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", selectByLocatorType(getValueFromPOM));
			Report_Functions.ReportEventSuccess (doc,"1","","'"+strTestObject+"' is clicked successfully ",2);	
			WebElementClick=true;
		}catch (Exception e) {
			Report_Functions.ReportEventFailure(doc,"","'"+strTestObject+"' was not clicked" , true); 
			WebElementClick=false;
			log.info("No Element Found to click :" + e);
		}
		return WebElementClick;
	}

	public static boolean javaScriptEnterText(String getValueFromPOM, String strTestObject, String strColumnName, int strExecEventFlag) throws Exception{

		boolean elementStatus = false;
		String elementValue = null;

		try{

			if(strExecEventFlag==1){
				elementValue = RetrieveTestDataValue("javaScriptDatePicker", strColumnName, strExecEventFlag);
			}

			if(elementValue == null){

				Report_Functions.ReportEventFailure(doc,  "javaScriptDatePicker",  "Required details are not provided in the data sheet.", false);
				return false;

			}

			//Get the locatorType from POM during runtime
			JavascriptExecutor js = (JavascriptExecutor) driver;
			//document.getElementById("txtExpireDate").innerHTML = "10/09/2020"
			//document.getElementById("text").innerHTML="some new text"

			log.info("Scrip is : document.getElementById(\""+getValueFromPOM+"\").value = \""+elementValue+"\"");
			js.executeScript("document.getElementById(\""+getValueFromPOM+"\").value = \""+elementValue+"\"");

			Report_Functions.ReportEventSuccess (doc,"1","","The Text '"+elementValue+"' is entered for the Element "+strTestObject+" using JavaScript",2);	
			elementStatus = true;

		}catch(Exception e){

			log.info("Exception occurred in web table radio button :"+e.getMessage());
			e.printStackTrace();
			Report_Functions.ReportEventFailure(doc,"","The Text '"+elementValue+"' is not entered for "+strTestObject+"  using JavaScript" , true);  
			elementStatus = false;

		}

		return elementStatus;

	}

	/*--------------------------------- FILE RELATED-----------------------------------------*/

	public static boolean deleteAllFileInPath(String filePath, int strExecEventFlag) throws Exception{

		boolean functionStatus = true;

		String path = null;
		int flag = 0;

		try{

			if(strExecEventFlag == 1){
				path = Param.getProperty(RetrieveTestDataValue("DeletelogFiles", filePath, strExecEventFlag));
			}

			if(path==null ){
				Report_Functions.ReportEventFailure(doc,  "DeletelogFiles",  "Required details are not provided in test data sheet.", false);
				return false;
			}


			File directory = new File("//\\" +path);


			for(File listOfFiles : directory.listFiles()){
				if(true){
					listOfFiles.delete();
					flag = 1;
				}
			}

		}catch(Exception e){
			log.info("Exception occurs in deleteFiles function "+e.getMessage());
			Report_Functions.ReportEventFailure(doc,"","Error occurred, while deleting the file in the Path", false);
			functionStatus = false;
		}

		if(flag == 1){
			Report_Functions.ReportEventSuccess(doc,"1","DeletelogFiles","All Files in the Path '"+path+"' are deleted sucessfully",3);
		} else {
			Report_Functions.ReportEventSuccess(doc,"1","DeletelogFiles","No file are available in the given Path '"+path+"' to delete.",3);
		}

		return functionStatus;
	}

	public static boolean xmlFileNodeUpdate(String Location,String AttributeXPath,String ValueToSet,int strExecEventFlag) throws Exception, IOException{
		log.info("XMLTextUpdate");
		boolean Executionstatus=false;

		if (Location==""){
			Report_Functions.ReportEventFailure(doc,  "XMLTextUpdate",  "Location Path for WebConfig is missing", true);
			return false;
		}
		if (AttributeXPath==""){
			Report_Functions.ReportEventFailure(doc,  "XMLTextUpdate",  "AttributeXPath Path for WebConfig is missing", true);
			return false;
		}
		if (ValueToSet==""){
			Report_Functions.ReportEventFailure(doc,  "XMLTextUpdate",  "ValueToSet in the node for WebConfig is missing", true);
			return false;
		}
		if(strExecEventFlag==1){
			Location=RetrieveTestDataValue("XMLTextUpdate",Location,strExecEventFlag);
			Location=Param.getProperty(Location);
			AttributeXPath=RetrieveTestDataValue("XMLTextUpdate",AttributeXPath,strExecEventFlag);
			ValueToSet=RetrieveTestDataValue("XMLTextUpdate",ValueToSet,strExecEventFlag);
			ValueToSet=Param.getProperty(ValueToSet);

			if (ValueToSet==""){
				Report_Functions.ReportEventFailure(doc,  "XMLTextUpdate",  "Value present in Property File Seems to Empty.Please check the property file.", true);
				return false;
			}
		}

		try {

			factory=DocumentBuilderFactory.newInstance();
			builder=factory.newDocumentBuilder();;
			file=new File("//\\"+Location);

			document=builder.parse(file);
			document.getDocumentElement().normalize();
			NodeList nodeList=null;
			xpath=XPathFactory.newInstance().newXPath();
			nodeList=(NodeList)xpath.compile(AttributeXPath).evaluate(document,XPathConstants.NODESET);

			nodeList.item(0).setTextContent(ValueToSet);


			TransformerFactory transFormerFactory = TransformerFactory.newInstance();
			Transformer transFormer = transFormerFactory.newTransformer();
			DOMSource source = new DOMSource(document);

			StreamResult result = new StreamResult(file);
			transFormer.transform(source, result);
			result.getOutputStream().close();
			Executionstatus=true;
			Report_Functions.ReportEventSuccess(doc, "1", "XMLTextUpdate", "XML config File '"+Location+"' has been updated successfully for the tag '"+AttributeXPath+"' with the value set as '"+ValueToSet+"'", 2);
			Thread.sleep(2000);
		} catch (ParserConfigurationException e) {
			log.info("catch ParserConfigurationException");
			e.printStackTrace();
			Report_Functions.ReportEventFailure(doc,  "XMLTextUpdate",  "ValueToSet in the node for WebConfig is Not successfull due to reason: '"+e.getMessage()+"'", false);
			Executionstatus=false;

		} catch (Exception e) {
			log.info("catch Excpetion");
			e.printStackTrace();
			Report_Functions.ReportEventFailure(doc,  "XMLTextUpdate",  "Exception occured during XMLTextUpdate. Reason: '"+e.getMessage()+"'", false);
			Executionstatus=false;
		}
		builder=null;
		xpath=null;
		nodeList=null;
		return Executionstatus;
	}

	/*--------------------------------- ALERT RELATED-----------------------------------------*/

	public static boolean alertAccept() throws Exception{

		boolean functionStatus = false;

		try{

			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			alert.getText();
			alert.accept();
			functionStatus=true;
			Report_Functions.ReportEventSuccess(doc, "1", "alertAccept", "Alert is accepted successfully", 2);

		}catch(Exception e){

			log.info("Exception occurred, while accepting the alert :"+e.getMessage());
			Report_Functions.ReportEventFailure(doc,"","Alert is not accepted" , true);
			functionStatus = false;

		}

		return functionStatus;

	}	

	/*--------------------------------- ***END***-----------------------------------------*/


}
