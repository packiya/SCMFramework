package Libraries;

import java.util.Arrays;

import Libraries.Driver_Script;
import Libraries.Function_Library;
import Libraries.Report_Functions;
import Utility.ReadExcel;
import Page_Objects.*;

public class App_Components extends Driver_Script {

	static boolean[] AppComponentStatus=null;
	static int[] appComponentEvents=null;

	public static int[] skipEvent(int[] appComponentEvents1,int  removeAction){
		int reorderedIndex = appComponentEvents1.length -1;
		for(int r=removeAction;r<reorderedIndex;r++){
			appComponentEvents[r]= appComponentEvents[r+1];
		}
		int[] appComponentEventstemp= Arrays.copyOf(appComponentEvents, reorderedIndex);
		return appComponentEventstemp;
	}

	public static int[] InitializeEvent(int  totalEvents, String  disableEvents){

		String[] eachDisabledEvents=null;
		int z;
		try{
			AppComponentStatus=new boolean[totalEvents];
			for(int m=0;m<(totalEvents);m++){
				AppComponentStatus[m]=true;
			}
			//Initializing the array with the values 1,2,3,4.... upto total events
			appComponentEvents =new int[totalEvents];
			for(int a=0;a<(totalEvents);a++){
				appComponentEvents[a]=a+1;
			}
			if(!( (disableEvents.equals("0") ) || (disableEvents.equals("0.0")) ) ){	
				log.info("Disable Events available...");
				//Retrieving each event seperately
				eachDisabledEvents=disableEvents.split(",");
				for(int de=0;de<eachDisabledEvents.length;de++){
					eachDisabledEvents[de]=eachDisabledEvents[de].replace(".0", "");
				}
				z=1;
				for(String  a : eachDisabledEvents ){
					//Call the skipEvent function	
					appComponentEvents=App_Components.skipEvent(appComponentEvents, Integer.parseInt(a)-z);
					z=z+1;	
				}
			}
		}catch(Exception e){
			log.info("Error inside InitializeEvent  : "+e);
			throw e;
		}finally{
			if(eachDisabledEvents!=null){
				for(int j=0;j<eachDisabledEvents.length;j++){
					eachDisabledEvents[j]=null;
				}
				eachDisabledEvents=null;
			}
		}
		return appComponentEvents;
	}

	public static void ValidateComponent(int[] appComponentEvents,boolean[] AppComponentStatus,int noEventStatus,String ComponentName) throws Exception{

		try{
			boolean testStepsStatus=true;
			for(int k=0;k<appComponentEvents.length;k++){
				boolean stepStatus=AppComponentStatus[k];
				if(stepStatus != true){
					testStepsStatus=false;
				}
			}
			if(noEventStatus==1){
				testStepsStatus=false;
			}
			//Vaidating the Result in Report
			Function_Library.Validate_AppComponent(ComponentName, testStepsStatus);
		}catch(Exception e){
			log.info("Error in ValidateComponent of App_Components  : "+e);
			throw e;
		}
	}

	/*-------------------------------- REFERENCE CODE ----------------------------------*/
	
	/**
	 * @Objective <b>Open the Given Browser and Launch the Application URL</b>
	 * @author <b>Lakshman</b>
	 * @since <b>18-DEC-16</b>
	 */

	public static void Launch_App() throws Exception{
		int noEventStatus = 0;
		int  totalEvents;
		String  disableEvents=null;
		String testFlow=null;

		try{
			totalEvents = 6;
			log.info("Total Events in the Component is : "+ totalEvents);
			disableEvents=ReadExcel.RetrieveEvents(Filepath, EnvironmentValue.getProperty("TESTCASE_NAME"), "Disable_Events", gblAppComponentCounter);
			log.info("Disable Events in the Component is : "+ disableEvents);

			if(totalEvents !=-1 &&  !(disableEvents.equals(""))){
				appComponentEvents=InitializeEvent(totalEvents,disableEvents);

				for (int testEvent=0;testEvent<appComponentEvents.length;testEvent++){
					testFlow="ACEvent" + appComponentEvents[testEvent];
					switch (testFlow) {
					case "ACEvent1": AppComponentStatus[testEvent] = Function_Library.launchApplication("URL",1);
					log.info(testFlow +" value is "+ AppComponentStatus[testEvent] );
					break;
					case "ACEvent2": AppComponentStatus[testEvent] = Function_Library.waitUntilElementExist(CRM_Login_Page.Login_Page("txtbox_UserName"), "Username");
					log.info(testFlow +" value is "+ AppComponentStatus[testEvent] ); 
					break;
					case "ACEvent3": AppComponentStatus[testEvent] = Function_Library.webelementEnterUsername(CRM_Login_Page.Login_Page("txtbox_UserName"), "Username", "Login_User_ID", 1);
					log.info(testFlow +" value is "+ AppComponentStatus[testEvent] );
					break;
					case "ACEvent4": AppComponentStatus[testEvent] = Function_Library.webelementEnterUsername(CRM_Login_Page.Login_Page("txtbox_Password"), "Password","Login_Password", 1);  
					log.info(testFlow +" value is "+ AppComponentStatus[testEvent] );
					break;
					case "ACEvent5": AppComponentStatus[testEvent] = Function_Library.webelementClick(CRM_Login_Page.Login_Page("btn_LogIn"), "Login");
					log.info(testFlow +" value is "+ AppComponentStatus[testEvent] );														
					break;
					case "ACEvent6": AppComponentStatus[testEvent] = Function_Library.waitUntilElementExist(CRM_Logout.Logout_Page("menu_Dropdown"), "Menu_Dropdown");
					log.info(testFlow +" value is "+ AppComponentStatus[testEvent] ); 
					break;

					default: Report_Functions.ReportEventFailure(doc, "App_Component", "Error in reading the step of the Application Component '" +EnvironmentValue.getProperty("App_Component_Name")+"'", false);
					noEventStatus=1;
					break;
					}

					if(!AppComponentStatus[testEvent]){
						if((Param.getProperty("Exclude_AP_If_Event_Failed")).equals("True") ){
							log.info("Exiting For Loop as TestEvent failed and breaking the AppComponent.");
							break;
						}
					}
				}
			}else{
				noEventStatus=1;
				Report_Functions.ReportEventFailure(doc, "", "Enter valid values in the Test Data spreadsheet in the columns Total_Events/Disable_Events", false);
			}

			ValidateComponent(appComponentEvents, AppComponentStatus,noEventStatus, EnvironmentValue.getProperty("App_Component_Name"));

		}catch(Exception e){
			log.info("Exception in AppComponent - "+EnvironmentValue.getProperty("App_Component_Name")+" is : "+ e);
			throw e;
		}finally{
			disableEvents=null;
			testFlow=null;
			AppComponentStatus=null;
			appComponentEvents=null;
		}
	}

	/**
	 * @Objective <b>Click Logout button and Close the browser</b>
	 * @author <b>Lakshman</b>
	 * @since <b>18-DEC-16</b>
	 */



	public static void Logout_App() throws Exception{
		int noEventStatus = 0;
		int  totalEvents;
		String  disableEvents=null;
		String testFlow=null;

		try{
			totalEvents = 6;
			log.info("Total Events in the Component is : "+ totalEvents);
			disableEvents=ReadExcel.RetrieveEvents(Filepath, EnvironmentValue.getProperty("TESTCASE_NAME"), "Disable_Events", gblAppComponentCounter);
			log.info("Disable Events in the Component is : "+ disableEvents);

			if(totalEvents !=-1 &&  !(disableEvents.equals(""))){
				appComponentEvents=InitializeEvent(totalEvents,disableEvents);

				for (int testEvent=0;testEvent<appComponentEvents.length;testEvent++){
					testFlow="ACEvent" + appComponentEvents[testEvent];
					switch (testFlow) {

					case "ACEvent1": AppComponentStatus[testEvent] = Function_Library.waitUntilElementExist(CRM_Logout.Logout_Page("menu_Dropdown"),  "Homepage_Menu");
					log.info(testFlow +" value is "+ AppComponentStatus[testEvent] );
					break;
					case "ACEvent2": AppComponentStatus[testEvent] = Function_Library.webelementClick(CRM_Logout.Logout_Page("menu_Dropdown"), "Homepage_Menu");
					log.info(testFlow +" value is "+ AppComponentStatus[testEvent] );
					break;
					case "ACEvent3": AppComponentStatus[testEvent] = Function_Library.webelementClick(CRM_Logout.Logout_Page("logout_Button"), "Logout_Button");
					log.info(testFlow +" value is "+ AppComponentStatus[testEvent] );
					break;
					case "ACEvent4": AppComponentStatus[testEvent] = Function_Library.alertAccept();
					log.info(testFlow +" value is "+ AppComponentStatus[testEvent] );
					break;
					case "ACEvent5": AppComponentStatus[testEvent] = Function_Library.waitUntilElementExist(CRM_Login_Page.Login_Page("btn_LogIn"), "Login_Button");
					log.info(testFlow +" value is "+ AppComponentStatus[testEvent] );														
					break;
					case "ACEvent6": AppComponentStatus[testEvent] = Function_Library.closeWebBrowser();
					log.info(testFlow +" value is "+ AppComponentStatus[testEvent] );
					break;
					default: Report_Functions.ReportEventFailure(doc, "App_Component", "Error in reading the step of the Application Component '" +EnvironmentValue.getProperty("App_Component_Name")+"'", false);
					noEventStatus=1;
					break;
					}

					if(!AppComponentStatus[testEvent]){
						if((Param.getProperty("Exclude_AP_If_Event_Failed")).equals("True") ){
							log.info("Exiting For Loop as TestEvent failed and breaking the AppComponent.");
							break;
						}
					}
				}
			}else{
				noEventStatus=1;
				Report_Functions.ReportEventFailure(doc, "App_componenet", "Enter valid values in the Test Data spreadsheet in the columns Total_Events/Disable_Events", false);
			}

			ValidateComponent(appComponentEvents, AppComponentStatus,noEventStatus, EnvironmentValue.getProperty("App_Component_Name"));

		}catch(Exception e){
			log.info("Exception in AppComponent - "+EnvironmentValue.getProperty("App_Component_Name")+" is : "+ e);
			throw e;
		}finally{
			disableEvents=null;
			testFlow=null;
			AppComponentStatus=null;
			appComponentEvents=null;
		}
	}

	/*-------------------------------- APPLICATION CODE ----------------------------------*/
	
	/**
	 * @Objective <b>Open the Given Browser and Launch the Application URL</b>
	 * @author <b>Lakshman</b>
	 * @since <b>18-DEC-16</b>
	 */

	public static void LAUNCH_DEMOQA_APP() throws Exception{
		int noEventStatus = 0;
		int  totalEvents;
		String  disableEvents=null;
		String testFlow=null;

		try{
			totalEvents = 2;
			log.info("Total Events in the Component is : "+ totalEvents);
			disableEvents=ReadExcel.RetrieveEvents(Filepath, EnvironmentValue.getProperty("TESTCASE_NAME"), "Disable_Events", gblAppComponentCounter);
			log.info("Disable Events in the Component is : "+ disableEvents);

			if(totalEvents !=-1 &&  !(disableEvents.equals(""))){
				appComponentEvents=InitializeEvent(totalEvents,disableEvents);

				for (int testEvent=0;testEvent<appComponentEvents.length;testEvent++){
					testFlow="ACEvent" + appComponentEvents[testEvent];
					switch (testFlow) {
					case "ACEvent1": AppComponentStatus[testEvent] = Function_Library.launchApplication("URL",1);
					break;
					case "ACEvent2": AppComponentStatus[testEvent] = Function_Library.waitUntilElementExist(DemoQA_Pages.homePage("linkRegistration"), "Registration");
					break;
					default: Report_Functions.ReportEventFailure(doc, "App_Component", "Error in reading the step of the Application Component '" +EnvironmentValue.getProperty("App_Component_Name")+"'", false);
					noEventStatus=1;
					break;
					}
					log.info(testFlow +" value is "+ AppComponentStatus[testEvent] );
					
					if(!AppComponentStatus[testEvent]){
						if((Param.getProperty("Exclude_AP_If_Event_Failed")).equals("True") ){
							log.info("Exiting For Loop as TestEvent failed and breaking the AppComponent.");
							break;
						}
					}
				}
			}else{
				noEventStatus=1;
				Report_Functions.ReportEventFailure(doc, "", "Enter valid values in the Test Data spreadsheet in the columns Total_Events/Disable_Events", false);
			}

			ValidateComponent(appComponentEvents, AppComponentStatus,noEventStatus, EnvironmentValue.getProperty("App_Component_Name"));

		}catch(Exception e){
			log.info("Exception in AppComponent - "+EnvironmentValue.getProperty("App_Component_Name")+" is : "+ e);
			throw e;
		}finally{
			disableEvents=null;
			testFlow=null;
			AppComponentStatus=null;
			appComponentEvents=null;
		}
	}

	public static void DO_REGIRSTRATION_WITH_SINGLE() throws Exception{
		int noEventStatus = 0;
		int  totalEvents;
		String  disableEvents=null;
		String testFlow=null;

		try{
			totalEvents = 21;
			log.info("Total Events in the Component is : "+ totalEvents);
			disableEvents=ReadExcel.RetrieveEvents(Filepath, EnvironmentValue.getProperty("TESTCASE_NAME"), "Disable_Events", gblAppComponentCounter);
			log.info("Disable Events in the Component is : "+ disableEvents);

			if(totalEvents !=-1 &&  !(disableEvents.equals(""))){
				appComponentEvents=InitializeEvent(totalEvents,disableEvents);

				for (int testEvent=0;testEvent<appComponentEvents.length;testEvent++){
					testFlow="ACEvent" + appComponentEvents[testEvent];
					switch (testFlow) {
					case "ACEvent1": AppComponentStatus[testEvent] = Function_Library.waitUntilElementExist(DemoQA_Pages.homePage("linkRegistration"), "Registration");
					break;
					case "ACEvent2": AppComponentStatus[testEvent] = Function_Library.webelementClick(DemoQA_Pages.homePage("linkRegistration"), "Registration");
					break;
					case "ACEvent3": AppComponentStatus[testEvent] = Function_Library.waitUntilElementExist(DemoQA_Pages.registrationPage("txtFirstname"), "First Name");
					break;
					case "ACEvent4": AppComponentStatus[testEvent] = Function_Library.webelementEnterText(DemoQA_Pages.registrationPage("txtFirstname"), "First Name","FirstName",1);
					break;
					case "ACEvent5": AppComponentStatus[testEvent] = Function_Library.webelementEnterText(DemoQA_Pages.registrationPage("txtLastname"), "Last Name","LastName",1);
					break;
					case "ACEvent6": AppComponentStatus[testEvent] = Function_Library.webradioSelect(DemoQA_Pages.registrationPage("rdbStatusSingle"), "Single", "Marital Status");
					break;
					case "ACEvent7": AppComponentStatus[testEvent] = Function_Library.webradioSelect(DemoQA_Pages.registrationPage("chkboxHobbyDance"), "Dance", "Hobby");
					break;
					case "ACEvent8": AppComponentStatus[testEvent] = Function_Library.weblistSelect(DemoQA_Pages.registrationPage("lstCountry"), "lstCountry", "Country",1);
					break;
					case "ACEvent9": AppComponentStatus[testEvent] = Function_Library.weblistSelect(DemoQA_Pages.registrationPage("lstDOBMM"), "DOB Month", "Month",1);
					break;
					case "ACEvent10": AppComponentStatus[testEvent] = Function_Library.weblistSelect(DemoQA_Pages.registrationPage("lstDOBDD"), "DOB Date", "Day",1);
					break;
					case "ACEvent11": AppComponentStatus[testEvent] = Function_Library.weblistSelect(DemoQA_Pages.registrationPage("lstDOBYYYY"), "DOB Year", "Year",1);
					break;
					case "ACEvent12": AppComponentStatus[testEvent] = Function_Library.webelementEnterText(DemoQA_Pages.registrationPage("txtPhone"), "Phone Number", "PhoneNumber",1);
					break;
					case "ACEvent13": AppComponentStatus[testEvent] = Function_Library.webelementEnterTextWithRandomNumber(DemoQA_Pages.registrationPage("txtUsername"), "Username", "UserName",1);
					break;
					case "ACEvent14": AppComponentStatus[testEvent] = Function_Library.webelementEnterTextWithRandomNumberAtFront(DemoQA_Pages.registrationPage("txtEmail"), "Email", "Email",1);
					break;
					case "ACEvent15": AppComponentStatus[testEvent] = Function_Library.webelementEnterText(DemoQA_Pages.registrationPage("txtDesc"), "About Yourself", "AboutYourself",1);
					break;
					case "ACEvent16": AppComponentStatus[testEvent] = Function_Library.webelementEnterText(DemoQA_Pages.registrationPage("txtPassword"), "Password", "Password",1);
					break;
					case "ACEvent17": AppComponentStatus[testEvent] = Function_Library.webelementEnterText(DemoQA_Pages.registrationPage("txtConfirmPassword"), "ConfirmPassword", "ConfirmPassword",1);
					break;
					case "ACEvent18": AppComponentStatus[testEvent] = Function_Library.waitUntilElementExist(DemoQA_Pages.registrationPage("btnSubmit"), "Submit");
					break;
					case "ACEvent19": AppComponentStatus[testEvent] = Function_Library.webelementClick(DemoQA_Pages.registrationPage("btnSubmit"), "Submit");
					break;
					case "ACEvent20": AppComponentStatus[testEvent] = Function_Library.waitUntilElementExist(DemoQA_Pages.registrationPage("responseMsg"), "Registration Message");
					break;
					case "ACEvent21": AppComponentStatus[testEvent] = Function_Library.webelementTextCompare(DemoQA_Pages.registrationPage("responseMsg"), "Registration Message","Registration_SuccessMsg",1);
					break;
					
					default: Report_Functions.ReportEventFailure(doc, "App_Component", "Error in reading the step of the Application Component '" +EnvironmentValue.getProperty("App_Component_Name")+"'", false);
					noEventStatus=1;
					break;
					}
					log.info(testFlow +" value is "+ AppComponentStatus[testEvent] );
					
					if(!AppComponentStatus[testEvent]){
						if((Param.getProperty("Exclude_AP_If_Event_Failed")).equals("True") ){
							log.info("Exiting For Loop as TestEvent failed and breaking the AppComponent.");
							break;
						}
					}
				}
			}else{
				noEventStatus=1;
				Report_Functions.ReportEventFailure(doc, "", "Enter valid values in the Test Data spreadsheet in the columns Total_Events/Disable_Events", false);
			}

			ValidateComponent(appComponentEvents, AppComponentStatus,noEventStatus, EnvironmentValue.getProperty("App_Component_Name"));

		}catch(Exception e){
			log.info("Exception in AppComponent - "+EnvironmentValue.getProperty("App_Component_Name")+" is : "+ e);
			throw e;
		}finally{
			disableEvents=null;
			testFlow=null;
			AppComponentStatus=null;
			appComponentEvents=null;
		}
	}

	public static void LOGOUT_DEMOQA_APP() throws Exception{
		int noEventStatus = 0;
		int  totalEvents;
		String  disableEvents=null;
		String testFlow=null;

		try{
			totalEvents = 4;
			log.info("Total Events in the Component is : "+ totalEvents);
			disableEvents=ReadExcel.RetrieveEvents(Filepath, EnvironmentValue.getProperty("TESTCASE_NAME"), "Disable_Events", gblAppComponentCounter);
			log.info("Disable Events in the Component is : "+ disableEvents);

			if(totalEvents !=-1 &&  !(disableEvents.equals(""))){
				appComponentEvents=InitializeEvent(totalEvents,disableEvents);

				for (int testEvent=0;testEvent<appComponentEvents.length;testEvent++){
					testFlow="ACEvent" + appComponentEvents[testEvent];
					switch (testFlow) {
					case "ACEvent1": AppComponentStatus[testEvent] = Function_Library.waitUntilElementExist(DemoQA_Pages.homePage("imgSiteName"), "Site Image");
					break;
					case "ACEvent2": AppComponentStatus[testEvent] = Function_Library.webelementClick(DemoQA_Pages.homePage("imgSiteName"), "Site Image");
					break;
					case "ACEvent3": AppComponentStatus[testEvent] = Function_Library.waitUntilElementExist(DemoQA_Pages.homePage("linkRegistration"), "Registration");
					break;
					case "ACEvent4": AppComponentStatus[testEvent] = Function_Library.closeWebBrowser();
					break;
					default: Report_Functions.ReportEventFailure(doc, "App_Component", "Error in reading the step of the Application Component '" +EnvironmentValue.getProperty("App_Component_Name")+"'", false);
					noEventStatus=1;
					break;
					}
					log.info(testFlow +" value is "+ AppComponentStatus[testEvent] );
					
					if(!AppComponentStatus[testEvent]){
						if((Param.getProperty("Exclude_AP_If_Event_Failed")).equals("True") ){
							log.info("Exiting For Loop as TestEvent failed and breaking the AppComponent.");
							break;
						}
					}
				}
			}else{
				noEventStatus=1;
				Report_Functions.ReportEventFailure(doc, "", "Enter valid values in the Test Data spreadsheet in the columns Total_Events/Disable_Events", false);
			}

			ValidateComponent(appComponentEvents, AppComponentStatus,noEventStatus, EnvironmentValue.getProperty("App_Component_Name"));

		}catch(Exception e){
			log.info("Exception in AppComponent - "+EnvironmentValue.getProperty("App_Component_Name")+" is : "+ e);
			throw e;
		}finally{
			disableEvents=null;
			testFlow=null;
			AppComponentStatus=null;
			appComponentEvents=null;
		}
	}

	
}