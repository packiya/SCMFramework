package Page_Objects;

import java.util.Hashtable;

import Libraries.Driver_Script;

public class DemoQA_Pages extends Driver_Script{

	public static String homePage(String locator){

		try{
			Hashtable<String, String> hs = new Hashtable<String, String>();
		
			hs.put("linkRegistration", "linktext#Registration");
			hs.put("imgSiteName", "xpath#//a[@class='site-anchor']");
			

			Runtimevalue.setProperty("locatorType", hs.get(locator).split("\\#")[0]);
			String locate = hs.get(locator).split("\\#")[1];
			return locate;
		}catch(Exception e){
			log.info("Error occurred in POM classes :"+e);
		}
		return null;
	}
	
	public static String registrationPage(String locator){

		try{
			Hashtable<String, String> hs = new Hashtable<String, String>();
		
			hs.put("txtFirstname", "id#name_3_firstname");
			hs.put("txtLastname", "id#name_3_lastname");
			
			hs.put("rdbStatusSingle", "xpath#//input[@value='single']");
			hs.put("rdbStatusMarried", "xpath#//input[@value='married']");
			hs.put("rdbStatusDivorced", "xpath#//input[@value='divorced']");
			hs.put("chkboxHobbyDance", "xpath#//input[@value='dance']");
			hs.put("chkboxHobbyReading", "xpath#//input[@value='reading']");
			hs.put("chkboxHobbyCricket", "xpath#//input[@value='cricket ']");
			hs.put("lstCountry", "id#dropdown_7");
			hs.put("lstDOBMM", "id#mm_date_8");
			hs.put("lstDOBDD", "id#dd_date_8");
			
			hs.put("lstDOBYYYY", "id#yy_date_8");
			hs.put("txtPhone", "id#phone_9");
			hs.put("txtUsername", "id#username");
			
			hs.put("txtEmail", "id#email_1");
			hs.put("txtDesc", "id#description");
			hs.put("txtPassword", "id#password_2");
			hs.put("txtConfirmPassword", "id#confirm_password_password_2");
			hs.put("btnSubmit", "name#pie_submit");
			
			hs.put("responseMsg", "xpath#//p[@class='piereg_message']");
			
			Runtimevalue.setProperty("locatorType", hs.get(locator).split("\\#")[0]);
			String locate = hs.get(locator).split("\\#")[1];
			return locate;
		}catch(Exception e){
			log.info("Error occurred in POM classes :"+e);
		}
		return null;
	}

}