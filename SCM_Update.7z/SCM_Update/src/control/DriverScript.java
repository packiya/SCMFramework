package control;

import java.io.File;
import java.io.FileInputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import utils.Constants;
import utils.ReadExcel;
import wrappers.Components;

public class DriverScript {

	static Properties property;
	final static Logger log = Logger.getLogger(DriverScript.class);

	public static void main(String[] args) {
		
		
		Method componentNameInExcel=null;

		try {

			Components componentObject= new Components();
			
			PropertyConfigurator.configure("./src/property/log4j.properties");

			property  = new Properties();
			FileInputStream fis = new FileInputStream(new File("./src/property/SystemConfig.properties"));
			property.load(fis);

			log.info("*********** Test Batch Starts. Name : "+property.getProperty("testBatchFileName")+" ***********");

			//Start Reporting
			
			ReadExcel testBatchExcelObj = new ReadExcel(property.getProperty("testBatchFilePath")+property.getProperty("testBatchFileName")+".xlsx");
			int totalNoOfTestCaseInBatch = testBatchExcelObj.getRowCount(Constants.TestBatch_Sheet);
			log.info("Total No of TestCases : " + totalNoOfTestCaseInBatch );

			for(int testCaseNumber = 1; testCaseNumber <= totalNoOfTestCaseInBatch; testCaseNumber++) {
				
				log.info("*********** Test Case Starts. ***********");
				String testCaseExecuteStatus = testBatchExcelObj.getDataFromExcel(Constants.TestBatch_Sheet, testCaseNumber, Constants.TestCase_Execute_ColName);
				String testCaseName = testBatchExcelObj.getDataFromExcel(Constants.TestBatch_Sheet, testCaseNumber, Constants.TestCase_ColName);
				String testCaseDesc = testBatchExcelObj.getDataFromExcel(Constants.TestBatch_Sheet, testCaseNumber, Constants.TestDescription_ColName);
				
				if(testCaseExecuteStatus.trim().equalsIgnoreCase("Yes")){
					log.info("TestCase Name : " + testCaseName );
					log.info("TestCase Desc : " + testCaseDesc );
					
					//Start Parent TestCase

					ReadExcel testDataExcelObj = new ReadExcel(property.getProperty("testDataFilePath")+testCaseName+".xlsx");

					int totalNoOfComponentsInBatch = testDataExcelObj.getRowCount(testCaseName);
					log.info("Total No of Components : " + totalNoOfComponentsInBatch+"\n" );

					for(int componentNumber = 1; componentNumber <= totalNoOfComponentsInBatch; componentNumber++ ) {
						String componentExecutionFlag = testDataExcelObj.getDataFromExcel(testCaseName, componentNumber, Constants.Comp_Execute_ColName);
						String componentName = testDataExcelObj.getDataFromExcel(testCaseName, componentNumber, Constants.Comp_Order_ColName);
						String componentDesc = testDataExcelObj.getDataFromExcel(testCaseName, componentNumber, Constants.Comp_Desc_ColName);

						if(componentExecutionFlag.trim().equalsIgnoreCase("Yes")) {
							log.info("Component Name 	: " +componentName);
							log.info("Component Desc 	: " +componentDesc);
							//Start Child Test
							
							String totalEvents = testDataExcelObj.getDataFromExcel(testCaseName, componentNumber, Constants.Comp_TEvents_ColName);
							log.info("Total Events 	: " +totalEvents);

							String disableEvents = testDataExcelObj.getDataFromExcel(testCaseName, componentNumber, Constants.Comp_DEvents_ColName);
							log.info("Disable Events 	: " +disableEvents);

							int totalNoTestDataInComponentSheet = testDataExcelObj.getRowCount(componentName);

							for(int testDataNumber = 1; testDataNumber <= totalNoTestDataInComponentSheet; testDataNumber++) {
								String testDataExecutionFlag = testDataExcelObj.getDataFromExcel(componentName, testDataNumber, Constants.TestData_Execute_ColName);

								if(totalNoTestDataInComponentSheet>1){
									
									//Report a step for showing the TestData number
									
								}
								
								
								if(testDataExecutionFlag.trim().equalsIgnoreCase("Yes")){
									String testDataObjective = testDataExcelObj.getDataFromExcel(componentName, testDataNumber, Constants.Comp_Desc_ColName);
									log.info("TestData Objective : "+testDataObjective);
								}

								try{
									//Reflection API to call methods at runtime with 1 Parameter(String)
									@SuppressWarnings("rawtypes")
									Class[] paramTypes = new Class[1];
									paramTypes[0]=String.class;
									
									componentNameInExcel = componentObject.getClass().getMethod(componentName,paramTypes);
									componentNameInExcel.invoke(componentObject,disableEvents);

								}catch(NoSuchMethodException e){
									log.info("NoSuchMethodException thrown. Details : "+e);

								}catch(InvocationTargetException e){
									log.info("InvocationTargetException thrown. Details : "+e);
								}finally{

								}

							}
						}
						log.info("");
					}

				}else{
					log.info("TestCase : '" + testCaseName+"' is set to NO" );
				}
				log.info("*********** Test Case Ends. ***********\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
