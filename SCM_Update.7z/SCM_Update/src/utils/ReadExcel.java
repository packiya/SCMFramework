package utils;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {
	
	String filePath;
	String sheetName;
	
	public ReadExcel(String filePath) {
		this.filePath=filePath;
	}
	
	public ReadExcel(String filePath, String sheetName) {
		this.filePath=filePath;
		this.sheetName = sheetName;
	}
	
	public int getRowCount()
	{
		try
		{
			File file = new File(filePath);
			FileInputStream fis = new FileInputStream(file);
			XSSFWorkbook workbook= new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName);

			workbook.close();
			fis.close();
			return (sheet.getLastRowNum());
		}catch(Exception e)
		{
			e.printStackTrace();
			return -1;
		}
	}

	public int getRowCount( String sheetName)
	{
		try
		{
			File file = new File(filePath);
			FileInputStream fis = new FileInputStream(file);
			XSSFWorkbook workbook= new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName);

			workbook.close();
			fis.close();
			return (sheet.getLastRowNum());
		}catch(Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}
	
	public String getDataFromExcel(int rowId, String attributeName){
		try{
			String strValue = null;
			File file = new File(filePath);
			FileInputStream fis = new FileInputStream(file);
			XSSFWorkbook workbook= new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName);
			XSSFRow row = sheet.getRow(0);

			int cellCount = row.getLastCellNum();
			int cellId = 0;
			for(int i = 0; i < cellCount; i++) {
				XSSFRow rownew = sheet.getRow(0);
				if(rownew.getCell(i).getStringCellValue().trim().equalsIgnoreCase(attributeName)) {
					cellId = i;
				}
			}
			row = sheet.getRow(rowId);
			strValue = row.getCell(cellId).getStringCellValue();

			workbook.close();
			fis.close();
			return strValue;

		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public String getDataFromExcel( String sheetName, int rowId, String attributeName){
		try{
			//String strValue = null;
			String value=null;
			File file = new File(filePath);
			FileInputStream fis = new FileInputStream(file);
			XSSFWorkbook workbook= new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName);
			XSSFRow row = sheet.getRow(0);

			int cellCount = row.getLastCellNum();
			int cellId = 0;
			for(int i = 0; i < cellCount; i++) {
				XSSFRow rownew = sheet.getRow(0);
				if(rownew.getCell(i).getStringCellValue().trim().equalsIgnoreCase(attributeName)) {
					cellId = i;
				}
			}
			row = sheet.getRow(rowId);
			//strValue = row.getCell(cellId).getStringCellValue();
			
			XSSFCell cell = row.getCell(cellId);
			if(cell.getCellType() == XSSFCell.CELL_TYPE_BLANK){
				value = "";
			} else {
				value = cellToString(cell);
			}

			workbook.close();
			fis.close();
			return value;

		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public int randomNumber()
	{
	   int range = (9999 - 1000) + 1;     
	   return (int)(Math.random() * range) + 1000;
	}

	public String cellToString(XSSFCell cell){
		int type;
		Object result=null;
		
		try{
			type = cell.getCellType();		
			switch (type){
			case 0 : double value = cell.getNumericCellValue();
			int pos = String.valueOf(value).lastIndexOf(".");
			if (pos > 0) {
				result = String.valueOf(value).substring(0, pos);
			}
			break;
			case 1 : result = cell.getStringCellValue();
			break;
			case 3 : result = "";
			break;
			default :
				throw new RuntimeException("Unsupportd cell - cellToString.");			
			}
			return result.toString();
			
		}catch(Exception e){
			throw e;
		}
	}

}
