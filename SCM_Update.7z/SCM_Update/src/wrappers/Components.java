package wrappers;

public class Components extends FunctionLibrary{


	public void LoginDemoApp(String disableEvents){

		launchApplication("");
		clickAWebElement("demoQA.home.registration");
		
		log.info("In LoginDemoApp component");
	
	}

	public void DoRegistrationForMale(String disableEvents){

		log.info("In DoRegistrationForMale component");

	}
	
	public void DoRegistrationForFemale(String disableEvents){
		
		log.info("In DoRegistrationForFemale component");

	}

	public void LogoutDemoApp(String disableEvents){

		log.info("In LogoutDemoApp component");

	}
	

}
