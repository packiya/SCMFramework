package report;

import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import wrappers.FunctionLibrary;

public class Reporter extends FunctionLibrary{

	private static ExtentReports extent;
	private static ExtentTest rTestcase;
	private static ExtentTest rComponent;
	private static String dateFolder;
	private static String reportFileName=null;
	public static Properties sysProperty;

	public static void startReport() throws Exception {

		sysProperty = new Properties();
		FileInputStream fis = new FileInputStream(new File("./src/property/SystemConfig.properties"));
		sysProperty.load(fis);
		
		//For folder
		dateFolder=new SimpleDateFormat ("dd_MM_yyyy").format(new Date());
		
		//For Report file name
		String datetime=new SimpleDateFormat ("_ddMMyyyy_hhmmss_a").format(new Date());
		reportFileName=sysProperty.getProperty("extentReportFileName")+datetime+".html";

		extent = new ExtentReports("./"+sysProperty.getProperty("extentReportFilePath")+dateFolder+"/"+reportFileName, true);
		extent.loadConfig(new File(sysProperty.getProperty("extentReportConfigFile")));

	}
	
	public static void addReportInfo(String param, String Value){
		extent.addSystemInfo(param,Value);
	}

	public static void startTestCase(String testCaseName, String testDescription){
		rTestcase = extent.startTest(testCaseName, testDescription);
	}

	public static void skipTestCase(String testCaseName, String testDescription,String category,String authorName){
		startTestCase(testCaseName, testDescription, category, authorName);
		rTestcase.log(LogStatus.SKIP, "'"+testCaseName+"' Execution status - No in TestBatch.");
		extent.endTest(rTestcase);
	}
	
	public static void failTestCaseNoSheet(String testCaseName, String testDescription,String category,String authorName){
		startTestCase(testCaseName, testDescription, category, authorName);
		rTestcase.log(LogStatus.FATAL, "'"+testCaseName+"' TestData Excel does not have the Sheet named same as TestData Excel FileName");
		log.error("TestData Excel does not have the Sheet named  [ "+testCaseName+" ] which is same as TestData Excel FileName");
		extent.endTest(rTestcase);
	}

	public static void startTestCase(String testCaseName, String testDescription,String category,String authorName){
		rTestcase = extent.startTest(testCaseName, testDescription);
		//Add Category(s)
		String[] arrCategory = category.split(",");
		for (String eachCategory : arrCategory) {
			if( !(eachCategory.equals("")) ){
				rTestcase.assignCategory(eachCategory.trim());
			}
		}
		//Add Author(s)
		String[] arrAuthor = authorName.split(",");
		for (String eachAuthor : arrAuthor) {
			if( !(eachAuthor.equals("")) ){
				rTestcase.assignAuthor(eachAuthor.trim());
			}
		}
	}

	public static void assignCategory(String category){
		String[] arrCategory = category.split(",");
		for (String eachCategory : arrCategory) {
			if( !(eachCategory.equals("")) ){
				rTestcase.assignCategory(eachCategory.trim());
			}
		}
	}

	public static void assignAuthor(String authorName){
		String[] arrAuthor = authorName.split(",");
		for (String eachAuthor : arrAuthor) {
			if( !(eachAuthor.equals("")) ){
				rTestcase.assignAuthor(eachAuthor.trim());
			}
		}
	}

	public static void startComponent(String componentName, String componentDesc){
		rComponent = extent.startTest(componentName, componentDesc);
	}

	public static void reportStepPass(String desc) {
		log.info("Step Pass : "+desc);
		rComponent.log(LogStatus.PASS, desc);
	}

	public static void reportStepFail(String desc, boolean takeScreenShot) {

		log.error("Step Fail : "+desc);

		if(takeScreenShot){

			String  ssFileName=new SimpleDateFormat ("dd_MM_yyyy_hh_mm_ss_a").format(new Date());
			//Make a directory if not available for Extent Reports
			if(!(new File(System.getProperty("user.dir")+"/"+sysProperty.getProperty("extentReportFilePath")+dateFolder+"/"+"_Screenshots/").exists())){
				new File(System.getProperty("user.dir")+"/"+sysProperty.getProperty("extentReportFilePath")+dateFolder+"/"+"_Screenshots/").mkdir();
			}

			//Create Screenshots based in driver value
			if(driver.getSessionId() == null || driver.getSessionId().toString().length()==0){
				try {
					Robot robot = new Robot();
					String fileName =System.getProperty("user.dir")+"/"+sysProperty.getProperty("extentReportFilePath")+dateFolder+"/"+"_Screenshots/"+ssFileName+".jpg";
					Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
					BufferedImage screenFullImage = robot.createScreenCapture(screenRect);
					ImageIO.write(screenFullImage, "jpg", new File(fileName));
				} catch (Exception e) {
					log.error("Exception while creating ScreenShot using Robot. Exception is --> "+ e);
				}

			}else{
				try {
					FileUtils.copyFile(driver.getScreenshotAs(OutputType.FILE) , new File("./"+sysProperty.getProperty("extentReportFilePath")+dateFolder+"/"+"_Screenshots/"+ssFileName+".jpg"));
				} catch (IOException e) {
					log.error("Exception while creating ScreenShot using WebDriver. Exception is --> "+ e);
				}
			}
			
			rComponent.log(LogStatus.FAIL, desc+rComponent.addScreenCapture("./_Screenshots/"+ssFileName+".jpg"));	
		}else{
			rComponent.log(LogStatus.FAIL, desc);
		}
	}

	public static void reportStepInfo(String desc) {
		log.info("Step Info : "+desc);
		rComponent.log(LogStatus.INFO, desc);
	}

	public static void reportStepError(String desc) {
		log.error("Step Error : "+desc);
		rComponent.log(LogStatus.ERROR, desc);
	}

	public static void appendComponent(){
		rTestcase.appendChild(rComponent);
	}

	public static void endTestCase(){
		extent.endTest(rTestcase);
		extent.flush();
	}

	public static void endReport(){
		extent.flush();
		addReportInfo("Generated Report Filename", reportFileName);
		extent.flush();

	}

}