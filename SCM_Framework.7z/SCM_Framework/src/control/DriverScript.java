package control;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.Test;

import utils.Constants;
import utils.ReadExcel;

public class DriverScript {

	static Properties property;
	final static Logger log = Logger.getLogger(DriverScript.class);

	@Test
	public void main() {

		try {
			
			PropertyConfigurator.configure("./src/property/log4j.properties");
			
			String dateForFile ="";
			Date date = new Date();

			SimpleDateFormat sDF = new SimpleDateFormat("yyyy_MM_dd_hh:mm:ss");
			dateForFile = dateForFile.concat(sDF.format(date));
			
			System.out.println(dateForFile);
			
			
			property  = new Properties();
			FileInputStream fis = new FileInputStream(new File("./src/property/SystemConfig.properties"));
			property.load(fis);

			String tcBatchFilePath =property.getProperty("testBatchFilePath");
			String tcBatchFileName = property.getProperty("testBatchFileName");
			
			ReadExcel testBatchExcelObj = new ReadExcel(tcBatchFilePath+tcBatchFileName+".xlsx");
			int rowCount = testBatchExcelObj.getRowCount(Constants.TestBatch_Sheet);

			for(int i = 1; i <= rowCount; i++) {

				String testExe = testBatchExcelObj.getDataFromExcel(Constants.TestBatch_Sheet, i, Constants.TestCase_Execute_ColName);

				if(true == testExe.trim().equalsIgnoreCase("Yes"))	{

					String tcName = testBatchExcelObj.getDataFromExcel(Constants.TestBatch_Sheet, i, Constants.TestCase_ColName);
					String tcDesc = testBatchExcelObj.getDataFromExcel(Constants.TestBatch_Sheet, i, Constants.TestDescription_ColName);

					System.out.println("TestCaseName: " + tcName + " and TestCase Description: " +tcDesc+ "\n");

					String testDataPath = property.getProperty("testDataFilePath");

					ReadExcel testDataExcelObj = new ReadExcel(testDataPath+tcName+".xlsx");
					int testDataRowCount = testDataExcelObj.getRowCount(tcName);

					System.out.println("Sheet: " +tcName+ "\t" +"contains rowCount: "+ testDataRowCount );

					for(int j = 1; j <= testDataRowCount; j++ ) {

						String tcExec = testDataExcelObj.getDataFromExcel(tcName, j, Constants.Comp_Execute_ColName);

						if(true == tcExec.trim().equalsIgnoreCase("Yes")) {

							String tcTotalEvents = testDataExcelObj.getDataFromExcel(tcName, j, Constants.Comp_TEvents_ColName);
							System.out.println("TotalEvents is: " +tcTotalEvents+ "\n");

							/*String tcDisableEvents = testDataExcelObj.getDataFromExcel(tcName, j, Constants.Comp_DEvents_ColName);
							System.out.println("Component DisableEvents is: " +tcDisableEvents+ "\n");
*/
							String tcExecOrder = testDataExcelObj.getDataFromExcel(tcName, j, Constants.Comp_Order_ColName);
							System.out.println("Component Execution order is: " +tcExecOrder+ "\n");

							String tcAppDesc = testDataExcelObj.getDataFromExcel(tcName, j, Constants.Comp_Desc_ColName);
							System.out.println("Component App Description is: " +tcAppDesc+ "\n");

							if(0 != testDataExcelObj.getRowCount(tcExecOrder)) {
								for(int k = 1; k <= testDataExcelObj.getRowCount(tcExecOrder); k++) {
									String cSheet = testDataExcelObj.getDataFromExcel(tcExecOrder, k, Constants.TestData_Execute_ColName);
									if(cSheet.toLowerCase().equalsIgnoreCase("yes")){
										System.out.println(testDataExcelObj.getDataFromExcel(tcExecOrder, k, Constants.TestData_Objective_ColName));
									}
								}
							}
						}
					}

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
