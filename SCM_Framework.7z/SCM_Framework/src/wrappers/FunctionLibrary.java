package wrappers;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import report.Reporter;
import utils.ReadExcel;

/**
 * @Description: General Functions which can used for writing test cases. 
 * @author Packiya Lakshmi Lakshman
 *
 */

public class FunctionLibrary implements BasicFunctions{

	protected static RemoteWebDriver driver;
	public Properties pageObj;
	ReadExcel readExcelObj = null;
	public static Logger log = Logger.getLogger(FunctionLibrary.class);
	
	
	public FunctionLibrary() {

		PropertyConfigurator.configure("./src/property/log4j.properties");
		
		log.info("Check");
		
	}
	
	

	@Override
	public boolean createExcelInstance(String filePath, String SheetName) {
		readExcelObj = new ReadExcel(filePath, SheetName);
		return true;
	}

	@Override
	public int getRowCountFromExcel() {
		return (readExcelObj.getRowCount());
	}

	@Override
	public boolean createExcelInstance(String filePath) {
		readExcelObj = new ReadExcel(filePath);
		return true;
	}

	@Override
	public int getRowCountFromExcelUsingSheetName(String sheetName) {
		return (readExcelObj.getRowCount(sheetName));
	}

	@Override
	public boolean launchApplication(String URL) {
		boolean functionStatus=false;
		try {
			System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
			driver = new ChromeDriver();
			//Maximize the window
			driver.manage().window().maximize();
			//Get the URL
			driver.get(URL);
			System.out.println("URL '"+URL+"' loaded successfully");
			//Wait for the Page to Load
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			functionStatus=true;
		} catch (Exception e) {
			log.info("URL '"+URL+"' in not loaded successfully");
			e.printStackTrace();
			functionStatus=false;
		}
		return functionStatus;
	}

	@Override
	public WebElement getLocator(String locatorKey) {

		WebElement element=null;

		try {
			pageObj = new Properties();
			FileInputStream fis = new FileInputStream(new File("./src/demoQA/project/property/OR.properties"));
			pageObj.load(fis);

			String locator = pageObj.getProperty(locatorKey);

			String locatorType=locator.split("#")[0];
			String locatorValue=locator.split("#")[1];

			switch (locatorType.toLowerCase().trim()) {
			case "id": element=driver.findElement(By.id(locatorValue));
			break;
			case "xpath": element=driver.findElement(By.xpath(locatorValue));
			break;
			case "classname": element=driver.findElement(By.className(locatorValue));
			break;
			case "linktext": element=driver.findElement(By.linkText(locatorValue));
			break;
			case "name": element=driver.findElement(By.name(locatorValue));
			break;
			case "tagname": element=driver.findElement(By.tagName(locatorValue));
			break;
			default: 
				return (WebElement) new IllegalAccessException("Locator type invalid");
			}
		} catch (Exception e) {
			System.out.println("Error occured while finding an element"+ e);
			e.printStackTrace();
			return null;
		}
		return element;
	}

	@Override
	public boolean enterATextInWebElement(String locatorKey, String columnNameInExcel, int rowId, String attributeName) {

		try {

			String textToEnter =  readExcelObj.getDataFromExcel(rowId, attributeName);
			WebElement element = getLocator(locatorKey);
			element.clear();
			element.sendKeys(textToEnter);
			System.out.println("Text entered successfully");
			return true;

		} catch (Exception e) {
			System.out.println("Exception occured while entering a Text "+e);
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean clickAWebElement(String locatorKey) {
		try {
			WebElement element = getLocator(locatorKey);
			element.click();
			Reporter.reportStepPass("Element clicked successfully");
			return true;
		} catch (Exception e) {
			Reporter.reportStepFail("Exception occured while clicking a Text",true);
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean selectByVisibleText(String locatorKey, String visibleText) {
		try {
			WebElement selectElement = getLocator(locatorKey);
			Select select = new Select(selectElement);
			select.selectByVisibleText(visibleText);
			System.out.println("Option  '"+visibleText+"'is selected successfully in the element '"+locatorKey+"'");
			return true;
		} catch (Exception e) {
			System.out.println("Option  '"+visibleText+"'is not selected in the element '"+locatorKey+"'");
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean selectByIndex(String locatorKey, int indexValue) {

		try {
			WebElement selectElement = getLocator(locatorKey);
			Select select = new Select(selectElement);
			select.selectByIndex(indexValue);
			System.out.println("Option  '"+indexValue+"'is selected successfully in the element '"+locatorKey+"'");
			return true;
		} catch (Exception e) {
			System.out.println("Option  '"+indexValue+"'is not selected in the element '"+locatorKey+"'");
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean selectByValue(String locatorKey, String value) {
		try {
			WebElement selectElement = getLocator(locatorKey);
			Select select = new Select(selectElement);
			select.selectByValue(value);
			System.out.println("Option  '"+value+"'is selected successfully in the element '"+locatorKey+"'");
			return true;
		} catch (Exception e) {
			System.out.println("Option  '"+value+"'is not selected in the element '"+locatorKey+"'");
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public String getTextByXpath(String locatorKey) {
		WebElement element=null;
		try {
			element = getLocator(locatorKey);
			String str = element.getText();
			System.out.println("Received String ["+str+"] from"+element);
			return str;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Failed to retrive message from ["+element+ "]");
		}
		return null;
	}

	@Override
	public boolean verifyTextInAWebElement(String locatorKey, String expectedText) {
		WebElement element=null;
		boolean functionStatus=false;

		try {
			element = getLocator(locatorKey);
			String text = element.getText();
			System.out.println("Received String ["+text+"] from"+element);

			if(text.trim().equals(expectedText)){
				functionStatus=true;
			}else{
				functionStatus=false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Failed to retrive message from ["+element+ "]");
		}
		return functionStatus;
	}
	
	@Override
	public boolean waitForanElementUsingId(String element, int sec) {
		
		WebDriverWait wait = new WebDriverWait(driver, sec);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(element)));
		return true;
	}

	@Override
	public boolean closeBrowser() {

		try{
			driver.close();
			driver.quit();
			return true;
		}catch (Exception e) {

		}
		return false;
	}
}