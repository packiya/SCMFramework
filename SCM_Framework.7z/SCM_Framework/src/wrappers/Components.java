package wrappers;

public class Components extends FunctionLibrary{


	public void LoginApp(){

		launchApplication("https://github.com/");
		clickAWebElement("github.home.signin");
	
	}

	public void DoRegistrationForMale(){

	
		clickAWebElement("demoQA.home.submit");	
		verifyTextInAWebElement("demoQA.home.result", "Result");

	}

	public void LogoutApp(){

		clickAWebElement("github.home.signout");
		closeBrowser();

	}



}
