package visualBI_Test;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class TodoTestCases {
	static WebDriver driver = null;

	private static ExtentReports report; 
	static ExtentTest testcase = null;
	static ExtentTest child = null;

	static WebElement element = null;
	TodoTestCases () {
		
		report = new ExtentReports("D:\\JavaProjects\\seleniumLearning\\Report\\TestReport.html", true);
		report.loadConfig(new File("D:\\JavaProjects\\seleniumLearning\\src\\property\\extent-config.xml"));
	}
	public WebElement getLocator(String locatorType, String locatorValue) {
		try {
			switch(locatorType.toLowerCase().trim()) {
			case "id":
				element = driver.findElement(By.id(locatorValue));
				break;
			case "xpath":
				element = driver.findElement(By.xpath(locatorValue));
				break;
			case "className":
				element = driver.findElement(By.className(locatorValue));
				break;
			case "linkText":
				element = driver.findElement(By.linkText(locatorValue));
				break;
			default:
				child.log(LogStatus.FAIL, "Invalid LocatorType received");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return element;
	}

	public boolean enterATextInWebElement(String locatorType, String locatorValue, String textToEnter) {

		try {
			element = getLocator(locatorType, locatorValue);
			element.sendKeys(textToEnter);
			element.submit();
			
			child.log(LogStatus.PASS, "Text entered successfully");
		} catch (Exception e) {
			child.log(LogStatus.FAIL, "Exception occured while entering a Text "+e);
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean clickAWebElement(String locatorType, String locatorValue) {
		try {
			element = getLocator(locatorType, locatorValue);
			element.click();
			child.log(LogStatus.PASS, "Element clicked successfully");
		} catch (Exception e) {
			child.log(LogStatus.FAIL, "Exception occured while clicking an element"+e);
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean launchApplication() {
		try {
			child = new ExtentTest("TodoActions", "Performing Todo Testcases");
		
			//System.setProperty("webdriver.chrome.driver", "D:\\JavaProjects\\seleniumLearning\\drivers\\chromedriver.exe");
			driver = new FirefoxDriver();
			driver.get("http://todomvc.com/examples/vanillajs/#/");

			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}

	public void closeBrowser() {
		driver.close();
		driver.quit();
	}
	@Test
	public void enterTodoData() {
		testcase = new ExtentTest("EnterToDoData", "Entering 2 items in the Todo List");
		
		child = new ExtentTest("LaunchApplication", "Entering the URL to launch the application");
		if( true == launchApplication()) {
			child.log(LogStatus.PASS, "URL loaded successfully");
		}else {
			child.log(LogStatus.FAIL, "URL failed to load");
		}
		
		enterATextInWebElement("xpath", "//input[@class='new-todo']",  "Todo");
		enterATextInWebElement("xpath", "//input[@class='new-todo']",  "Todo1");
		
		testcase.appendChild(child);
		report.endTest(testcase);
		report.flush();
		
		closeBrowser();
	}
}
