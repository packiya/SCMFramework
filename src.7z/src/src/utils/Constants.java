package utils;

public class Constants {
	
	//TestBatch sheet
    public static String TestBatch_Sheet ="Test_Case_List";
    public static String TestCase_ColName ="Test_Case_Name";
    public static String TestDescription_ColName ="Test_Case_Description";
    public static String TestCase_Execute_ColName ="Test_Case_Execute";
    public static String TestModule_ColName ="Module_Name";
    public static String TestAuthor_ColName ="Author_Name";
    
    //TestData sheet
    public static String Comp_Execute_ColName ="App_Component_Execute";
    public static String Comp_Order_ColName ="Execution_Order";
    public static String Comp_Desc_ColName ="App_Component_Description";
    public static String  Comp_TEvents_ColName="Total_Events";
    public static String  Comp_DEvents_ColName="Disable_Events";
    
    //TestData Component sheet
    public static String TestData_Execute_ColName ="TestData_Execute";
    public static String TestData_Objective_ColName="Objective";
    
    //Yes No values
    public static String RUNMODE_YES="Yes";
    public static String RUNMODE_NO="No";
}
