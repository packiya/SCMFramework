package wrappers;

import org.openqa.selenium.WebElement;

public interface BasicFunctions {

	public boolean createExcelInstance(String filePath, String SheetName);
	
	public int getRowCountFromExcel();
	
	public int getRowCountFromExcelUsingSheetName(String sheetName);
	
	public boolean createExcelInstance(String filePath);
	
	public boolean launchApplication(String URL);
	
	public WebElement getLocator(String key);

	public boolean enterATextInWebElement(String locatorKey, String columnNameInExcel, int rowId, String attributeName);
	
	public boolean enterATextInWebElement(String locatorKey, int rowId, String attributeName);
	
	public boolean clickAWebElement(String key);
	
	public String getTextByXpath(String element);

	public boolean selectByVisibleText(String key, String visibleText);

	public boolean selectByIndex(String key, int indexValue);

	public boolean selectByValue(String key, String value);
	
	public boolean verifyTextInAWebElement(String locatorKey, String expectedText);
	
	public boolean waitForanElementUsingId(String element, int sec);
	
	public boolean closeBrowser();
}
