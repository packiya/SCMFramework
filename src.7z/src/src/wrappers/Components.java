package wrappers;

import report.Reporter;

public class Components extends FunctionLibrary{

	public void LoginDemoApp(String disableEvents){

		if(true == launchApplication(appObj.getProperty("appURL"))) {
			Reporter.reportStepPass("URL Launched successfully");
		}else {
			Reporter.reportStepFail("Failed to load URL", false);
		}
		clickAWebElement("demoQA.home.registration");

		log.info("In LoginDemoApp component");
	}

	public void DoRegistration(String disableEvents, String testCaseName){

		String filePath = sysObj.getProperty("testDataFilePath")+testCaseName+".xlsx";

		try {
			
			if(true == createExcelInstance(filePath)) {
				log.debug("File path: " + filePath +" is successfully loaded" ); 
			} else {
				log.error("Failed to load the Excel File in the path: " + filePath + "\n");
			}

			int rowCount = getRowCountFromExcelUsingSheetName("DoRegistration");

			for(int i = 1; i <= rowCount; i++) {
				enterATextInWebElement("demoQA.home.firstName", i, "FirstName");
				enterATextInWebElement("demoQA.home.lastName", i, "LastName");
				clickAWebElement("demoQA.home.singleStatus");
				clickAWebElement("demoQA.home.danceHobby");
				selectByVisibleText("demoQA.home.country", "Country");
				selectByVisibleText("demoQA.home.month", "Month");
				selectByVisibleText("demoQA.home.day", "Day");
				selectByVisibleText("demoQA.home.year", "Year");
				enterATextInWebElement("demoQA.home.phoneNum", i, "PhoneNum");
				enterATextInWebElement("demoQA.home.userName", i, "UserName");
				enterATextInWebElement("demoQA.home.email", i, "E-mail");
				enterATextInWebElement("demoQA.home.aboutMe", i, "AboutMe");
				enterATextInWebElement("demoQA.home.password", i, "Password");
				enterATextInWebElement("demoQA.home.confirmPassword", i, "ConfirmPassword");
			}
			log.info("In DoRegistrationForMale component");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void DoRegistrationForFemale(String disableEvents){

		log.info("In DoRegistrationForFemale component");

	}

	public void LogoutDemoApp(String disableEvents){

		log.info("In LogoutDemoApp component");

	}


}
